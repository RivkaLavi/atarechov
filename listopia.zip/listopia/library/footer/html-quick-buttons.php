<div class="jvbpd-quick-buttons">
	<a id="back-to-top" href="#" class="btn btn-primary btn-lg back-to-top javo-dark admin-color-setting hidden" role="button" title="<?php esc_attr_e('Go to top', 'listopia' );?>">
		<span class="fa fa-arrow-up"></span>
	</a>
	<?php if( $jvbpd_tso->get('scroll_rb_contact_us', '') == 'use'): ?>
	<a class="btn btn-primary btn-lg javo-quick-contact-us javo-dark admin-color-setting">
		<span class="fa fa-envelope-o"></span>
	</a>
	<?php endif; ?>
</div>