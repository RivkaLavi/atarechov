<?php
global $jvbpd_query;
if( function_exists( 'jvbpd_folio' ) )
	jvbpd_folio()->displayCustomFields();