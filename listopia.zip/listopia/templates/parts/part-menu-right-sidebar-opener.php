<div class="overlay-sidebar-opener">
	<a href="javascript:void(0)"><i class="jvbpd-icon2-paragraph"></i></a>
</div>