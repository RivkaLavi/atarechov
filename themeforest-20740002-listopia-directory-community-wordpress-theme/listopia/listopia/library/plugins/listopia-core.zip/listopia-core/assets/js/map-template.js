/**
 *
 * Map Template Script
 * @author javo Themes
 * @since 1.0.0
 * @description Lava Direction Map Template Script
 *
 */

( function( $ ){
	"use strict";

	var
		BTN_OK = $( '[javo-alert-ok]' ).val(),
		ERR_LOC_ACCESS = jvbpd_core_map_param.strLocationAccessFail;

	window.jvbpd_map_box_func = {

		options:{

			// Lava Configuration
			config:{
				items_per: $('[name="javo-box-map-item-count"]').val()
			},

			// Google Map Parameter Initialize
			map_init:{
				map:{
					options:{
						mapTypeId: google.maps.MapTypeId.ROADMAP,
						mapTypeControl	: true,
						mapTypeControlOptions:{
							position:google.maps.ControlPosition.RIGHT_TOP
						},
						gestureHandling : 'cooperative', /* greedy, cooperative */
						panControl : false,
						scrollwheel : true,
						streetViewControl : true,
						zoomControl : true,
						zoomControlOptions : {
							position : google.maps.ControlPosition.RIGHT_BOTTOM,
							style : google.maps.ZoomControlStyle.SMALL
						 }
					},
					events : {
						click : function(){
							var obj = window.jvbpd_map_box_func;
							obj.close_ib_box();
						}
					}
				},
				_blank_panel:{
					options:{
						content:$('#lynk-map-inner-panel').html()
					}
				}
			},

			// Google Point Of Item(POI) Option
			map_style : [
				{
					featureType: "poi",
					elementType: "labels",
					stylers: [
						{ visibility: "off" }
					]
				}
			]
		} // End Options

		,variable:{
			top_offset:
				parseInt( $('header > nav').outerHeight() || 0 ) +
				parseInt( $('#wpadminbar').outerHeight() || 0 )

			// Topbar is entered into Header Navigation.
			// + $('.javo-topbar').outerHeight()

		}, // End Define Variables

		getOptions : function() {
			// Ajax
			this.ajaxurl = obj.args.ajaxurl;
			this.click_on_marker_zoom	= parseInt( obj.args.marker_zoom_level ) || false;
		}

		// Lava Maps Initialize
		, init: function()
		{

			/*
			*	Initialize Variables
			*/
			var obj					= this;

			this.args				= jvbpd_core_map_param;

			this.getOptions();

			// Map Element
			this.el					= $('.javo-maps-area');
			this.panel				= $( ".javo-maps-panel-wrap" );

			// Google Map Bind
			this.el					.gmap3( this.options.map_init );
			this.map				= this.el.gmap3('get');

			this.map.setOptions({ styles: this.getStyles() });

			// MouseWheel
			/*
			if( obj.args.allow_wheel )
				this.map.setOptions({ scrollwheel : true });
			*/

			//this.tags				= $('[javo-map-all-tags]').val().toLowerCase().split( '|' );
			this.tags				= new Array();

			// Layout
			this.layout();

			// Trigger Resize
			this.resize();

			// Setup Distance Bar
			this.setDistanceBar();
			this.menuFilters();

			// Hidden Footer
			$('.container.footer-top').remove();

			// Set Google Information Box( InfoBubble )
			this.setInfoBubble();

			this.bindSearchShortcode();

			var
				is_cross_domain = obj.args.cross_domain == '1',
				json_hook = obj.args.json_hook,
				json_ajax_url = obj.args.json_file,
				json_security = obj.args.json_security,
				parse_json_url = json_ajax_url;

			if( is_cross_domain ) {
				parse_json_url = this.ajaxurl;
				parse_json_url += "?action=" + json_hook;
				parse_json_url += "&fn=" + json_ajax_url.replace( '.json', '' );
				parse_json_url += "&security=" + json_security;
				parse_json_url += "&callback=?";
			}

			this.bindMobile();

			// Events
			; $( document )
				.on( 'click'	, '.javo-hmap-marker-trigger', this.marker_on_list )
				//.on( 'change'	, 'select[name^="filter"]', this.filter_trigger )
				.on( 'click'	, '[data-javo-map-load-more]', this.load_more() )
				// .on( 'click', 'button[name="map_order[order]"]', this.order_switcher() )
				.on( 'change', '.module-switcher input[name="module_switcher"]', this.module_switcher() )
				.on( 'click', '[data-menu-filter] [data-value]', this.menu_filter() )
				.on( 'click', '.javo-map-filter-order > label.btn', this.order_switcher() )
				.on( 'change', 'input[name="map_order[orderby]"]', function(){ obj.filter(); })
				.on( 'keypress'	, '#javo-map-box-auto-tag', this.keyword_ )
				.on( 'click'	, '[data-map-move-allow]', this.map_locker )
				.on( 'click'	, '#javo-map-box-search-button', this.search_button )
				.on( 'click'	, '.javo-my-position', this.getMyPosition() )
				.on( 'click'	, '.current-search', this.currentBoundSearch() )
				.on( 'click'	, '.reset-filter', this.filter_reset() )
				.on( 'click', '.jvbpd-map-mobile-switch', this.mobile_type_switcher() )
				.on( 'getMyPosition', this.getMyPosition() )
				.on( 'keydown'	, '#javo-map-box-location-ac', this.setGetLocationKeyword )
				.on( 'keydown'	, '#javo-map-box-location-trigger', this.trigger_location_keyword() )
				.on( 'change'	, 'select[name^="list_filter"]', this.trigger_selectize_filter() )
				.on( 'javo:filter_reset', this.filter_reset() )
				.on( 'javo:map_refresh', function(){ obj.filter(); })
				.on( 'javo:doing', this.doing() )
				.on( 'javo:map_pre_get_lists', this.control_manager( true ) )
				.on( 'javo:map_get_lists_after', this.control_manager( false ) )
				.on( 'javo:map_info_window_loaded', this.info_window_events() )

			; $( window )
				.on( 'resize', this.resize )
				.on( 'javo:init', this.setAutoComplete )
				.on( 'javo:map_get_lists_after', function() {
					$( document ).trigger( 'lava:favorite' );
				});

			this.moduleLink();

			$( window ).trigger( 'javo:init', obj );

			; if( typeof this.append_function == 'function' )
				this.append_function();

			// DATA
			$.getJSON( parse_json_url, function( response ) {
				obj.items = response;
				$.each( response, function( index, key ){
					obj.tags.push( key.post_title );
				} );

				obj.setKeywordAutoComplete();
				$( document.body ).trigger( 'javo:json_loaded', obj.items );
			})
			.fail( function( xhr ) {
				console.log( xhr.responseText );
				obj.items = [];
				obj.filter();
			} );

		} // End Initialize Function

		, clear_map: function()
		{
			//
			this.el.gmap3({
				clear:{
					name:[ 'marker', 'circle' ]
				}
			});
			this.close_ib_box();

		}

		, close_ib_box: function()
		{
			if( typeof this.infoWindo != "undefined" ) {
				this.infoWindo.close();
			}
		}

		, filter_trigger: function(e) {
			var obj = window.jvbpd_map_box_func;
			obj.filter();
		}

		, trigger_selectize_filter : function() {
			var obj		= this;
			return function() {
				var taxonomy	= $( this ).data( 'tax' );
				if( taxonomy ) {
					var sel = $( ".javo-maps-search-wrap [name='map_filter[" + taxonomy + "]']" ).get(0);
					if( typeof sel !== 'undefined' && typeof sel.selectize !== 'undefined' ) {
						sel.selectize.setValue( $( this ).val() );
					}
				}
			}
		},

		layout: function() {

			var obj = window.jvbpd_map_box_func;

			// Initalize DOC
			$('body').css('overflow', 'hidden');

			// POI Setup
			if ( $('[name="jvbpd_google_map_poi"]').val() == "off" ) {
				// Map Style
				this.map_style = new google.maps.StyledMapType( this.options.map_style, {name:'Lava Box Map'});
				this.map.mapTypes.set('map_style', this.map_style);
				this.map.setMapTypeId('map_style');
			}
			$( window ).on( 'load', function() {
				/** Disabled
				$( '.javo-maps-favorites-panel' ).removeClass('hidden')
					.css({
						marginLeft: ( -$('.javo-maps-favorites-panel').outerWidth(true)) + 'px'
						, marginTop: obj.variable.top_offset + 'px'
					}); */
			} );

		}, // End Set Layout

		resize: function() {

			var
				obj				= window.jvbpd_map_box_func
				, winX			= $(window).width()
				, winY			= 0
				, body			= $( 'html body' )
				, adminbarH	= $('#wpadminbar').outerHeight(true);

			// winY += $('header.main').outerHeight(true);
			winY += $('nav.navbar-static-top').outerHeight(true);
			winY += $('#javo-maps-listings-switcher').outerHeight(true);
			winY += adminbarH;

			if( ! $('.javo-maps-area-wrap').hasClass( 'top-bottom-layout' ) ) {
				$('.javo-maps-area-wrap').css( 'top', winY );
				// $('.javo-maps-search-wrap' ).css( 'top', winY );
				// $('.javo-maps-panel-wrap').css( 'top', winY);
				$( '#javo-maps-wrap' ).css( 'top', winY);
			}

			$( 'body' ).css( 'paddingTop' , adminbarH + 'px' );
			body.addClass( "over-flow-y-scroll" );

			if( parseInt( winX ) >= 1120 && obj.list_type == 'map' ) {
				body.addClass( "no-scrolling" );
			}else{
				body.removeClass( "no-scrolling" );
			}

			$( document ).trigger( 'javo:map_template_reisze', winX );

		}, // End Responsive( Resize );

		setDistanceBar: function() {

			var
				self = this,
				args = self.args,
				sliderArgs = {
					elements : $( '.javo-geoloc-slider' ),
					unit : args.distance_unit || 'km',
					distance : 1000,
					max : args.distance_max || 50,
					final_max : 50,
					step : parseInt( args.distance_max ) / 100,
					current : 10000,
					getParams : function() {
						return {
							start : this.current,
							step : this.step,
							connect : 'lower',
							range : { 'min' : 0, 'max' : this.final_max },
							serialization : {
								lower : new Array(
									$.Link( {
										target : '-tooltip-<div class="javo-slider-tooltip"></div>',
										method : function( v ) {
											var template = '<span>{current_distance} {distance_unit}</span>';
											template = template.replace( /{current_distance}/g, v );
											template = template.replace( /{distance_unit}/g, sliderArgs.unit );
											$( this ).html( template );
										},
										format : {
											decimals : 0,
											thousand : ',',
											encoder : function( value ) {
												return parseFloat( value ) / sliderArgs.distance;
											}
										}
									} )
								)
							}
						};
					},
					events : {
						getLocation : function( control ) {
							var obj = sliderArgs;
							return function( results ) {

								var current_distance = parseInt( $( control ).val() );

								if( ! results ){
									alert( ERR_BED_ADDRESS );
									return false;
								};

								var
									latlng = results[0].geometry.location,
									result = [],
									data = self.items,
									geo_input = $( '.javo-location-search' );

								$( control ).parent().addClass( 'open' );

								$.each( self.items, function( i, k ) {
									var c = self.setCompareDistance( new google.maps.LatLng( k.lat, k.lng ), latlng );
									if( ( c * obj.distance ) <= current_distance ) {
										result.push( data[i] );
									}
								} );

								window.__LAVA_MAP_BOX_TEMP__ = result;

								self.filter( result );
								self.map_clear( false );
								self.el.gmap3({ clear:{ name: 'circle' } });

								$( this ).gmap3({
									circle:{
										options:{
											center : latlng,
											radius : current_distance,
											fillColor : '#2099CD',
											strokeColor : '#1A759C'
										}
									}
								}, {
									get:{
										name: 'circle'
										, callback: function(c){
											$( this ).gmap3( 'get' ).fitBounds( c.getBounds() );
										}
									}
								});
							}
						},
						set : function() {
							var obj = this;
							return function( event, value ) {

								var address = $( '[name="radius_key"]' ).val();

								if( ! address ) {
									return false;
								}

								self.el.gmap3( {
									getlatlng:{ 'address' : address,
									callback : obj.getLocation( this ) }
								} );

							}
						}
					}
				};

			sliderArgs.distance = sliderArgs.unit == 'km' ? 1000 : 1609.344;
			sliderArgs.final_max = parseInt( sliderArgs.max ) * sliderArgs.distance;
			sliderArgs.step = parseInt( sliderArgs.final_max ) / 100;
			sliderArgs.current = sliderArgs.distance * 10;

			sliderArgs.elements.each( function() {
				if( $( this ).hasClass( 'noUi-target' ) ) {
					return true;
				}
				$( this )
					.noUiSlider( sliderArgs.getParams() )
					.css( 'margin', '15px 0' )
					.on( 'set', sliderArgs.events.set() );
			} );

		}, // End Setup Distance noUISlider

		setAutoComplete : function() {

			$( ".javo-location-search" ).each(
				function( i, element ) {
					var google_ac = new google.maps.places.Autocomplete( element );
				}
			);

		}, // End Setup AutoComplete  Selectize

		map_locker: function( e ) {
			e.preventDefault();

			var
				obj = window.jvbpd_map_box_func,
				strLock	 = $( this ).data( 'lock' ),
				strUnlock = $( this ).data( 'unlock' );

			$( this ).toggleClass('active');

			if( $( this ).hasClass('active') ) {
				// Allow
				obj.map.setOptions({ draggable: true, scrollwheel: true });
				$( this ).find('i').removeClass('fa fa-lock').addClass('fa fa-unlock');
				$( this ).prop( 'title', strLock );
			}else{
				// Not Allowed
				obj.map.setOptions({ draggable:false, scrollwheel: false });
				$( this ).find('i').removeClass('fa fa-unlock').addClass('fa fa-lock');
				$( this ).prop( 'title', strUnlock );
			}
		},

		/** GOOGLE MAP TRIGGER				*/
		setInfoBubble: function() {
			this.infoWindo = new InfoBubble({
				minWidth:320
				, minHeight:190
				, overflow:true
				, shadowStyle: 1
				, padding: 0
				, borderRadius: 5
				, arrowSize: 20
				, borderWidth: 0
				, disableAutoPan: false
				, hideCloseButton: false
				, arrowPosition: 50
				, arrowStyle: 0
			});
		}, // End Setup InfoBubble

		search_button: function( e ) {
			e.preventDefault();
			var obj = window.jvbpd_map_box_func;
			if( $( "#javo-map-box-location-ac" ).val() ) {
				$( '.javo-geoloc-slider' ).trigger( 'set' );
			}else{
				obj.filter();
			}
		},

		bindSearchShortcode : function() {
			var
				self = this,
				container = $( '.jvbpd-header-map-filter-wrap' ),
				searchbar = $( '.shortcode-jvbpd_search1', container ),
				form = $( 'form', searchbar ),
				select_filters = $( 'select[data-tax]', searchbar ),
				address_filter = $( 'input[name="radius_key"]', searchbar ),
				keyword_filter = $( 'input[name="keyword"]', searchbar ),
				category_filter = $( '.field-ajax_search input[name="category"]', searchbar ),
				ajax_search_filter = $( '.field-ajax_search input[name="s"]', searchbar );

			// self.setKeywordAutoComplete( keyword_filter );
			// $( document.body ).trigger( 'javo:json_loaded' );

			self.searchbar = searchbar;
			self.el_keyword = keyword_filter;

			form.on( 'submit', function( e ) {
				e.preventDefault();
				if( address_filter.val() ) {
					self.distancebar_in_search();
					$( '.javo-geoloc-slider' ).trigger( 'set' );
				}else{
					self.filter();
				}
			} );
			ajax_search_filter.on( 'keypress', function( event ) {
				if( event.keyCode == 13 ) {
					category_filter.val( '' );
					self.filter();
					return false;
				}
			} );

			$( document ).ready( function() {
				var
					selectCallback = function( event, ui ) {
						$( window ).trigger( 'javo:ajax-search-select', ui );
						category_filter.val( '' );
						if( ui.item.type == 'listing_category' ) {
							event.preventDefault();
							category_filter.val( ui.item.object_id );
							self.amenities_filter( ui.item.object_id );
							$( this ).val( ui.item.label );
							self.filter();
						}
						return false;
					};
				ajax_search_filter.autocomplete( 'option', 'select', selectCallback );

			} );

			$( document.body ).on( 'javo:json_loaded', function() {
				form.trigger( 'submit' );
			} );

		},

		keywordMatchesCallback : function( tags ) {
			return function keywordFindMatches( q, cb ) {
				var matches, substrRegex;

				substrRegex		= new RegExp( q, 'i');
				matches			= [];

				$.each( tags, function( i, tag ){
					if( substrRegex.test( tag ) ){
						matches.push({ value : tag });
					}
				});
				cb( matches );
			}
		},

		setKeywordAutoComplete: function() {
			this.el_keyword.typeahead({
				hint			: false,
				highlight		: true,
				minLength		: 1
			}, {
				name			: 'tags'
				, displayKey	: 'value'
				, source		: this.keywordMatchesCallback( this.tags )
			}).closest('span').css({ width: '100%' });
		},

		filter : function( data ) {
			var obj			= window.jvbpd_map_box_func;

			if( $( '.javo-my-position' ).hasClass( 'active' ) ) {
				var items	= window.__LAVA_MAP_BOX_TEMP__ || obj.items;
			}else{
				var items	= data || obj.items;
			}

			items = obj.apply_multiple_filter( $("[name='jvbpd_map_multiple_filter']") , items );
			items = obj.apply_meta_filter( $( "[data-metakey]", obj.panel ), items );

			// items = obj.apply_keyword( items );
			// items = obj.filterCategoryAndTags( items );

			items = obj.search_shortcode_filters( items );
			items = obj.apply_menu_filters( items );

			if( typeof obj.extend_filter == 'function' ) {
				items = obj.extend_filter( items );
			}

			/* Sort */{
				// items = obj.apply_order( items );
			}

			/* Featured Item Filter */{
				items = obj.featured_filter( items );
			}

			obj.setMarkers( items );

			$('.javo-maps-panel-list-output #products > .row').empty();
			$('#javo-listings-wrapType-container').empty();
			obj.apply_item = items;
			obj.append_list_item( 0 );


			$( document ).trigger( 'javo:map_updated', [ items ] );
		},

		filter_reset : function () {
			var self = this;
			return function () {
				var
					el_location		= $( "#javo-map-box-location-ac, #javo-map-box-location-trigger" ),
					el_terms		= $( "[name='jvbpd_map_multiple_filter'], [name='jvbpd_list_multiple_filter']" ),
					el_col_filter	= $( ".javo-map-box-filter-items [data-dismiss-filter]" );

				// Location initialize
				el_location.val( '' );

				// Other Column filter
				el_col_filter.trigger( 'click' );

				// Other filter initialize
				el_terms.prop( 'checked', false );
			}
		},

		mobile_type_switcher : function() {
			var
				self = this,
				container = $( '.javo-maps-container' ),
				list = $( '.javo-maps-panel-wrap', container ),
				map = $( '.javo-maps-area-wrap', container ),
				callback = function() {
					if( $( window ).width() <= 767 ) {
						$.map( new Array( list, map ), function( typeData ){ typeData.addClass( 'hidden' ); } );
					}
				}
			callback();
			list.removeClass( 'hidden' );
			return function( event ) {
				var button = $( this );

				callback();
				$.map( new Array( 'map-active', 'list-active' ), function( typeClass ) { button.removeClass( typeClass ); } );

				if( $( this ).data( 'current-type' ) == 'map' ) {
					list.removeClass( 'hidden' );
					$( this ).data( 'current-type', 'list' ).addClass( 'list-active' );
				}else{
					map.removeClass( 'hidden' );
					$( this ).data( 'current-type', 'map' ).addClass( 'map-active' );
					self.el.gmap3({ trigger: 'resize' }, 'autofit' );
				}
			}
		},

		apply_multiple_filter: function( terms, data ) {
			var
				obj = this,
				result = [],
				term = {},
				is_cond_and = obj.args.amenities_filter == 'and';

			terms.each(
				function()
				{
					var taxonomy = $( this ).data( 'tax' );
					if( $( this ).is( ":checked" ) )
						if( typeof term[ taxonomy ] == "undefined" ) {
							term[ taxonomy ] = new Array( $( this ).val() );
						}else{
							term[ taxonomy ].push( $( this ).val() );
						}
				}
			);

			if( Object.keys(term).length ){
				$.each(
					data,
					function( i, k ) {

						$.each(
							term,
							function( taxonomy, term_ids ) {
								var is_append = true;
								for( var j in term_ids ){
									if( typeof k[ taxonomy ] != "undefined" && k[ taxonomy ] ){
										if( k[ taxonomy ].indexOf( term_ids[j] ) > - 1 ) {
											if( is_cond_and ){
												is_append = is_append && true;
											}else{
												result.push( data[i] );
												return false;
											}
										}else{
											is_append = false;
										}
									} // if typeof
								} // For
								if( is_cond_and && is_append ) {
									result.push( data[i] );
								}
							}
						);
					}
				);
			}else{
				result = data;
			}
			return result;
		},

		apply_meta_filter : function( filters, items ) {
			if( filters.length ) {
				$.each( filters, function( indexFilteri , element ) {
					var
						result			= [],
						strKey		= $( this ).data( 'metakey' ),
						strValue		= $( this ).val();

					if( strValue ) {
						$.each( items, function( i, k ) {
							if( k[ strKey ] && k[ strKey ].toString().indexOf( strValue ) > -1 ) {
								result.push( items[i] );
							}
						} );
						items = result;
					}
				} );
			}
			return items;
		},

		compate_keyword : function( data, keyword ) {
			var
				self = this,
				result = new Array();

			if( keyword != "" && typeof keyword != "undefined" ) {
				keyword = keyword.toLowerCase();
				$.each( data , function( i, k ){
					if(
						self.tag_matche( k.tags, keyword ) ||
						k.post_title.toLowerCase().indexOf( keyword ) > -1
					){
						result.push( data[i] );
					}
				});
			}else{
				result = data;
			}
			return result;
		},

		apply_keyword: function( data ) {
			return this.compate_keyword( data, this.el_keyword.val() );
		},

		filterCategoryAndTags : function( data ) {
			var
				self = this,
				result = new Array(),
				key_result = new Array(),
				cat_result = new Array(),
				taxonomy = 'listing_category',
				searchbar = self.searchbar,
				cagetory = $( 'select[data-category-tag="' + taxonomy + '"]', searchbar ),
				query = cagetory.val() || '',
				query_string = cagetory.text();

			result = self.compate_keyword( data, query_string );

			if( query != '' ) {
				$.each( data, function( i, k ) {
					if( typeof k[ taxonomy ] != "undefined" && k[ taxonomy ] ) {
						if( k[ taxonomy ].indexOf( query ) > - 1 ){
							result.push( data[i] );
							return false;
						}
					}
				} );
			}
			return result;
		},

		search_shortcode_filters : function( data ) {
			var
				self = this,
				result = new Array(),
				find_words = new Array(),
				taxonomy = 'listing_category',
				container = $( '.jvbpd-header-map-filter-wrap' ),
				searchbar = $( '.shortcode-jvbpd_search1', container ),
				ajax_search_filter = $( '.field-ajax_search input[name="s"]', searchbar ),
				serach_result_cache = ajax_search_filter.parent().data( 'las-instance' )._cache || new Array(),
				search_result_items = serach_result_cache[ ajax_search_filter.val() ] || false,
				query = $( 'input[name="category"]', searchbar ).val() || '';

			query = query.toString();

			if( query != '' ) {
				$.each( data, function( i, k ) {
					if( typeof k[ taxonomy ] != "undefined" && k[ taxonomy ] ) {
						if( k[ taxonomy ].indexOf( query ) > - 1 ){
							result.push( data[i] );
						}
					}
				} );
			}else{
				if( search_result_items ) {
					$.each( search_result_items, function( index, item ) {
						if( item.type == 'listings' && item.object_id ) {
							find_words.push( item.object_id );
						}
					} );
					$.each( data, function( i, k) {
						if( find_words.indexOf( k.post_id.toString() ) > -1 ) {
							result.push( data[i] );
						}
					});
				}else{
					result = data;
				}
			}
			return result;
		},

		order_raty : function( type ) {
			return function( a, b ) {
				if( type == 'reviewed' ) {
					return parseInt( a.rating_count || 0 ) > parseInt( b.rating_count || 0 ) ? -1 : parseInt( a.rating_count || 0 ) < parseInt( b.rating_count || 0 ) ? 1: 0;
				} else {
					return parseFloat( a.rating || 0 ) > parseFloat( b.rating || 0 ) ? -1 : parseFloat( a.rating || 0 ) < parseFloat( b.rating || 0 ) ? 1: 0;
				}
			}
		},

		apply_working_hours_filter : function( item ) {
			var
				result = new Array(),
				currentTime = new Date(),
				currentDateIndex = parseInt( ( currentTime.getDay() + 6 ) % 7 );

			$.each( item, function( index, data ) {
				if( data.working_hours ) {
					var workData = data.working_hours[ currentDateIndex ];
					if( workData.isActive ) {
						var
							openHour = new Date(),
							parseOpenHour = workData.timeFrom.split( ':' ),
							closeHour = new Date(),
							parseCloseHour = workData.timeTill.split( ':' );

						openHour.setHours( parseOpenHour[0] );
						openHour.setMinutes( parseOpenHour[1] );
						closeHour.setHours( parseCloseHour[0] );
						closeHour.setMinutes( parseCloseHour[1] );

						if( openHour < currentTime && currentTime < closeHour ) {
							result.push( item[ index ] );
						}
					}
				}
			} );
			return result;
		},

		apply_menu_filters : function( items ) {
			var self = this;

			items = self.objToArray( items );

			$( '[data-menu-filter]' ).each( function( filterIndex, filterData ) {
				var
					results = new Array(),
					filterName = $( this ).data( 'menu-filter' ),
					filterValue = $( this ).data( 'filter-value' ),
					filterType = $( this ).data( 'filter-type' );
				if( ! filterValue ) {
					return true;
				}

				if( filterName == 'rating' ) {
					if( [ 'high', 'low' ].indexOf( filterValue ) >= 0 ) {
						items.sort( self.order_raty() );
						if( 'low' == filterValue ) {
							items.reverse();
						}
					}else if( typeof filterValue == 'number' ) {
						results = $.grep( items, function( itemData ) {
							return parseInt( itemData.rating ) == filterValue;
						} );
						items = results;
					}
					return true;
				}

				if( filterName == 'order' && filterValue ) {
					items.sort( self.compare( filterValue ) );
					if( filterType == 'desc' ) {
						items.reverse();
					}
					return true;
				}

				if( filterName == 'reviewed' && $( '[data-value]', this ).hasClass( 'active' ) ) {
					items.sort( self.order_raty( 'reviewed' ) );
					return true;
				}

				if( filterName == 'favorite' && $( '[data-value]', this ).hasClass( 'active' ) ) {
					items.sort( self.compare( 'favorite' ) );
					return true;
				}

				if( filterName == 'openhour' && $( '[data-value]', this ).hasClass( 'active' ) ) {
					items = self.apply_working_hours_filter( items );
					return true;
				}

			} );

			return items;
		},

		apply_menu_filters_ : function( item ) {
			var
				self = this,
				results = new Array();

			$( '[data-menu-filter]' ).each( function( i, k ) {
				var
					button,
					result = new Array(),
					is_filtered = false,
					filter = $( this ).data( 'menu-filter' ),
					value = $( this ).data( 'filter-value' );

				if( 'rating' == filter && value != '' ) {
					switch( value ) {
						case 'high' :
							result = self.objToArray( item );
							result.sort( self.order_raty() );
							is_filtered = true;
							break;
						case 'low' :
							result = self.objToArray( item );
							result.sort( self.order_raty() );
							result.reverse();
							is_filtered = true;
							break;
						case 5 : case 4 : case 3 : case 2 : case 1 :
							$.each( item, function( ii, data ) {
								if( parseInt( data.rating ) == parseInt( value ) ) {
									result.push( item[ ii ] );
								}
							} );
							is_filtered = true;
					}
				}else if( 'order' == filter && value != '' ) {
					result = self.objToArray( item );
					result.sort( self.compare( value ) );
					is_filtered = true;
				}else if( 'reviewed' == filter && value != '' ) {
					if( $( '[data-value]', this ).hasClass( 'active' ) ) {
						result = self.objToArray( item );
						result.sort( self.order_raty( 'reviewed' ) );
						is_filtered = true;
					}
				}else if( 'favorite' == filter && value != '' ) {
					if( $( '[data-value]', this ).hasClass( 'active' ) ) {
						result = self.objToArray( item );
						result.sort( self.compare( 'favorite' ) );
						is_filtered = true;
					}
				}else if( 'openhour' == filter && value != '' ) {
					if( $( '[data-value]', this ).hasClass( 'active' ) ) {
						result = self.apply_working_hours_filter( item );
						is_filtered = true;
					}
				}
				if( is_filtered ) {
					item = result;
				}
			} );

			return item;
		},

		tag_matche: function( str, keyword ) {
			var i = 0;
			if( str != "" ) {
				for( i in str ) {
					if( str[i].toLowerCase().match( keyword ) ) {
						return true;
					}
				}
			}
			return false;
		},

		keyword_ : function( e ) {
			var obj			= window.jvbpd_map_box_func;
			if( e.keyCode == 13 ) {
				if( $( "#javo-map-box-location-ac" ).val() ) {
					$( '.javo-geoloc-slider' ).trigger( 'set' );
				}else{
					obj.filter();
				}
			}
		},

		featured_filter : function( data ){

			var
				obj = this,
				result = new Array(),
				features = new Array(),
				others = new Array();

			if( obj.args.panel_list_featured_first != 'enable' )
				return data;

			$.each( data, function( i, k ) {
				typeof k.f != 'undefined' && k.f.toString() == '1' ? features.push( data[ i ] ) : others.push( data[ i ] );
			} );

			result = $.merge( features, others );

			return result;
		},

		setMarkers: function( response ) {

			var item_markers	= new Array();
			var obj				= window.jvbpd_map_box_func;
			var bounds = new google.maps.LatLngBounds();

			obj.map_clear( true );

			if( response ) {
				$.each( response, function( i, item ){

					if( typeof item != "undefined" && item.lat != "" && item.lng != "" )
					{
						var
							default_marker	= obj.args.map_marker,
							map_marker	= item.icon || default_marker;

						if( obj.args.marker_type == 'default' )
							map_marker		= default_marker;

						item_markers.push( {
							//latLng		: new google.maps.LatLng( item.lat, item.lng )
							lat			: item.lat
							, lng		: item.lng
							, options	: { icon: map_marker }
							, id		: "mid_" + item.post_id
							, data		: item
						} );
						bounds.extend( new google.maps.LatLng( item.lat, item.lng ) );
					}
				});
			}

			if( item_markers.length > 0 )
			{

				var _opt = {
					marker:{
						values:item_markers
						, events:{
							click: function( m, e, c ){

								var map = $(this).gmap3( 'get' );
								obj.infoWindo.setContent( $( "#javo-map-loading-template" ).html() );
								obj.infoWindo.open( map, m);

								if( obj.click_on_marker_zoom )
									map.setCenter( m.getPosition() );

								//obj.ajaxurl

								$.post(
									obj.ajaxurl
									, {
										action		: "jvbpd_map_info_window_content"
										, post_id	: c.data.post_id
									}
									, function( response )
									{
										var str = '', nstr = '';
										if( response.state == "success" )
										{
											str = $('#javo-map-box-infobx-content').html();
											str = str.replace( /{post_id}/g		, response.post_id || '' );
											str = str.replace( /{post_title}/g	, response.post_title || '' );
											str = str.replace( /{post_date}/g	, response.post_date || '' );
											str = str.replace( /{permalink}/g	, response.permalink || '' );
											str = str.replace( /{thumbnail}/g	, response.thumbnail );
											str = str.replace( /{category}/g	, response.category || nstr );
											str = str.replace( /{location}/g	, response.location );
											str = str.replace( /{phone}/g		, response.phone || nstr );
											str = str.replace( /{mobile}/g		, response.mobile || nstr );
											str = str.replace( /{website}/g		, response.website || nstr );
											str = str.replace( /{email}/g		, response.email || nstr );
											str = str.replace( /{address}/g		, response.address || nstr );
											str = str.replace( /{author_name}/g	, response.author_name || nstr );
											str = str.replace( /{featured}/g	, ( typeof response.featured != 'undefined' ? 'featured-item' : '' ) );
											str = str.replace( /{type}/g		, response.type || nstr );
											str = str.replace( /{meta}/g		, response.meta || nstr );
											str = str.replace( /{rating}/g			, response.rating || '');

										}else{
											str = "error";
										}
										$( "#javo-map-info-w-content" ).html( str );
										$( document ).trigger( 'jvbpd_sns:init' );
										$( document ).trigger( 'javo:map_info_window_loaded' );
									}
									, 'json'
								)
								.fail( function( response ){
									//$.jvbpd_msg({ content: $( "[javo-server-error]" ).val(), delay: 10000 });
									// alert( $( "[javo-server-error]" ).val() );
									console.log( response.responseText );
								} );
							} // End Click
						} // End Event
					} // End Marker
				}

				if( obj.args.cluster != "disable" ) {
					_opt.marker.cluster = {
						radius: parseInt( obj.args.cluster_level || 50 )
						, 0:{ content:'<div class="javo-map-cluster admin-color-setting">CLUSTER_COUNT</div>', width:52, height:52 }
						, events:{
							click: function( c, e, d )
							{
								var $map = $(this).gmap3('get');
								var maxZoom = new google.maps.MaxZoomService();
								var c_bound = new google.maps.LatLngBounds();

								// IF Cluster Max Zoom ?
								maxZoom.getMaxZoomAtLatLng( d.data.latLng , function( response ){
									if( response.zoom <= $map.getZoom() && d.data.markers.length > 0 )
									{
										var str = '';

										str += "<ul class='list-group'>";

										str += "<li class='list-group-item disabled text-center'>";
											str += "<strong>";
												str += obj.args.strings.multiple_cluster;
											str += "</strong>";
										str += "</li>";

										$.each( d.data.markers, function( i, k ){
											str += "<a onclick=\"window.jvbpd_map_box_func.marker_trigger('" + k.id +"');\" ";
												str += "class='list-group-item'>";
												str += k.data.post_title;
											str += "</a>";
										});

										str += "</ul>";
										obj.infoWindo.setContent( str );
										obj.infoWindo.setPosition( c.main.getPosition() );
										obj.infoWindo.open( $map );

									}else{
										if( d.data.markers ) {
											$.each( d.data.markers, function( i, k ) {
												c_bound.extend( new google.maps.LatLng( k.lat, k.lng ) );
											} );
										}

										$map.fitBounds( c_bound );
										/*
										$map.setCenter( c.main.getPosition() );
										$map.setZoom( $map.getZoom() + 2 );
										*/
									}
								} ); // End Get Max Zoom
							} // End Click
						} // End Event
					} // End Cluster
				} // End If

				var init_mapZoom = parseInt( obj.args.map_zoom || 0 );

				if( init_mapZoom > 0 && !obj.zoom_lvl_once ){

					_opt.map = {
						options : { zoom : init_mapZoom }
					}

					_opt.map.options.center = _opt.map.options.center || bounds.getCenter();

					obj.zoom_lvl_once = obj.disableAutofit = true;

				}

				obj.extend_mapOption = {};

				$( document ).trigger( 'javo:parse_marker', obj );

				_opt = $.extend( true, {}, _opt || {}, obj.extend_mapOption || {} );

				if( !obj.disableAutofit ) {
					this.el.gmap3( _opt , "autofit" );
				}else{
					this.el.gmap3( _opt );
					obj.disableAutofit = false;
				}
				return false;
			}
		},

		map_clear: function( marker_with ) {
			var elements = new Array( 'rectangle' );
			if( ! $( '.javo-my-position' ).hasClass( 'active' ) )
				elements.push( 'circle' );

			if( marker_with )
				elements.push( 'marker' );

			this.el.gmap3({ clear:{ name:elements } });
			this.iw_close();
		},

		iw_close: function(){
			if( typeof this.infoWindo != "undefined" ) {
				this.infoWindo.close();
			}
		},

		load_more: function( e ) {
			var obj = window.jvbpd_map_box_func;
			return function( e ) {
				e.preventDefault();
				if( ! $( this ).data( 'origin-text' ) ) {
					$( this ).data( 'origin-text', $( this ).text() );
				}
				obj.append_list_item( obj.loaded_ );
			}
		},

		append_list_item: function( offset ) {
			var
				obj				= window.jvbpd_map_box_func,
				self = this
				, btn				= $( '[data-javo-map-load-more]' )
				, limit			= parseInt( obj.args.loadmore_amount || 10 )
				, panel			= $( ".javo-maps-panel-wrap" )
				, data			=  obj.apply_item
				, jv_integer	= 0;
			this.loaded_		= limit + offset;
			var ids				= new Array();

			if( data ) {
				$.each( data, function( i, k ){
					jv_integer++;
					if( jv_integer > obj.loaded_ ){ return false; }
					if( typeof k != "undefined" && jv_integer > offset ){
						ids.push( k.post_id );
					}
				});
			}

			btn.prop( 'disabled', true ).find('i').removeClass( 'hidden' );

			$( "#javo-listings-wrapType-container .message-dismiss" ).remove();

			$( document ).trigger( 'javo:map_pre_get_lists' );

			$.post(
				obj.ajaxurl, {
					action		: 'jvbpd_map_list',
					post_ids	: ids,
					template	: obj.args.template_id
				},
				function( response ) {
					var buf				= '';
					var buf_l			= '';

					var mapOutput, listOutput;

					mapOutput = listOutput = $( "[javo-map-item-not-found]" ).val();

					if( response && response.map )
						mapOutput	= response.map;

					if( response && response.list )
						listOutput		= response.list;

					$( '.javo-maps-panel-list-output #products > .row' ).append( mapOutput );
					$( '#javo-listings-wrapType-container' ).append( listOutput );
					$( document ).trigger( 'javo:map_get_lists_after' );
					btn.prop( 'disabled', false ).find('i').addClass('hidden');
					if( obj.loaded_ >= data.length ) {
						// btn.addClass( 'hidden' );
						btn.text( btn.data( 'nomore' ) ).prop( 'disabled', true ).addClass( 'disabled' );
					}else{
						// btn.removeClass( 'hidden' );
						btn.text( btn.data( 'origin-text' ) ).prop( 'disabled', false ).removeClass( 'disabled' );
					}
				}
				, "json"
			)
			.fail( function( response ) {
				console.log( response.responseText );
			} ) // Fail
			.always( function() {
				obj.resize();
			} ) // Complete
		},

		list_replace : function( str, data ) {
			var is_featured		= data.f === '1' ? 'space_featured' : false;

			str = str.replace(/{post_id}/g			, data.post_id );
			str = str.replace(/{post_title}/g		, data.post_title || '');
			str = str.replace(/{excerpt}/g			, data.post_content || '');
			str = str.replace(/{thumbnail_large}/g	, data.thumbnail_large || '');
			str = str.replace(/{permalink}/g		, data.permalink || '');
			str = str.replace(/{avatar}/g			, data.avatar || '');
			str = str.replace(/{rating}/g			, data.rating || 0);
			str = str.replace(/{favorite}/g			, data.favorite || '' );
			str = str.replace(/{location}/g			, data.location || '');
			str = str.replace(/{date}/g				, data.post_date || '');
			str = str.replace(/{author_name}/g		, data.author_name || '');
			str = str.replace(/{featured}/g			, is_featured );
			//
			str = str.replace(/{category}/g			, data.category || '');
			str = str.replace(/{type}/g				, data.type || '');
			return str;
		},

		trigger_marker: function( e ) {
			var obj = window.jvbpd_map_box_func;
			obj.el.gmap3({
					map:{ options:{ zoom: parseInt( $("[javo-marker-trigger-zoom]").val() ) } }
				},{
				get:{
					name:"marker"
					,		id: $( this ).data('id')
					, callback: function(m){
						google.maps.event.trigger( m, 'click' );
					}
				}
			});
		},

		order_switcher: function() {
			var obj = this;
			return function( e ) {
				e.preventDefault();

				var
					_current = $( this ).data( 'order' ) || 'desc',
					_after = _current == 'desc' ? 'asc' : 'desc';

				if( ! $( this ).hasClass( 'active' ) )
					return;

				$( 'span.desc, span.asc', this ).addClass( 'hidden' );
				$( 'span.' + _after, this ).removeClass( 'hidden' );
				$( this ).data( 'order', _after );

				obj.filter();
			}
		},

		bindMobile : function() {
			var
				self = this,
				template = $( "script#jvbpd-map-mobile-buttons" ).html(),
				resultDIV = $( '.javo-maps-panel-list-output' ),
				parentSection = resultDIV.closest( 'section.elementor-element' ),
				search_forms = $( '.elementor .shortcode-jvbpd_search1' );

			$( template ).insertBefore( parentSection );
			if( $( window ).width() > 767 ) {
				search_forms.remove();
			}
			self.bindMobileEvents();
		},

		bindMobileEvents : function() {
			var
				self = this,
				searchFilter = $( '.javo-maps-search-wrap' ),
				output = $( '.javo-maps-panel-list-output' ),
				filterCtlWrap = $( '.jvbpd-mobile-filter-controls' ),
				filterOpener = $( '.jvbpd-map-filter-opener', filterCtlWrap ),
				header_wrap = $( '.jvbpd-header-map-filter-wrap' ),
				search_in_header = $( '.javo-shortcode.shortcode-jvbpd_search1', header_wrap );

			if( $( window ).width() < 767 ) {
				searchFilter.addClass( 'hidden' );
			}
			filterOpener.on( 'click', function( event ) {
				searchFilter.toggleClass( 'hidden' );
				filterCtlWrap.toggleClass( 'filter-collapse' );
				output.toggleClass( 'hidden' );
			} );

			// $( '.field-google .javo-geoloc-trigger' ).on( 'click', self.distancebar_in_search() );
			 $( 'input[name="radius_key"]', search_in_header ).on( 'click', self.distancebar_in_search() );
		},

		distancebar_in_search : function( disable) {
			var self = this;
			return function( event ) {
				var
					distanceBar,
					headerFilterContainer = $( '.jvbpd-header-map-filter-container' ),
					headerSearchForm = $( '.javo-shortcode.shortcode-jvbpd_search1', headerFilterContainer ),
					addressFilter = $( '.field-google', headerSearchForm ),
					template = $( 'script#jvbpd-map-distance-bar' ).html() || '';

				if( disable ) {
					event.preventDefault();
				}

				if( ! addressFilter.hasClass( 'loaded-distance' ) ) {
					addressFilter.addClass( 'loaded-distance' ).append( template );
					self.setDistanceBar();

					$( 'button[data-close]', addressFilter ).on( 'click', function( event ) {
						distanceBar.removeClass( 'open' );
					} );
				}
				distanceBar = $( '.jvbpd-map-distance-bar-wrap', headerSearchForm );
				distanceBar.addClass( 'open' );
			}
		},

		module_switcher : function() {
			var
				self = this,
				container = $( '.javo-maps-panel-list-output' ),
				wrap = $( '#products', container ),
				ONEROW = 'one-row';
			return function( e ){
				var is_active = $( this ).hasClass( 'active' );
				if( $( this ).val() == 'list' ) {
					wrap.addClass( ONEROW );
				}else{
					wrap.removeClass( ONEROW );
				}
			}
		},

		menu_filter : function() {
			var self = this;
			return function( e ) {
				var
					order = $( this ).data( 'type' ) || '',
					filter = $( this ).closest( '[data-menu-filter]' );
				filter.data({
					'filter-value' : $( this ).data( 'value' ) || '',
					'filter-type' : order,
				});
				self.filter();
				$( this ).data( 'type', ( order == 'desc' ? 'asc' : 'desc' ) );
				$( this ).closest( '.dropdown-item' ).removeClass( 'asc desc' );
				$( this ).closest( '.dropdown-item' ).addClass( $( this ).data( 'type' ) );
			}
		},

		menuFilters : function() {
			var near_me = $( '[data-menu-filter="nearme"]' );

			near_me.on( 'click', function() {
				navigator.geolocation.getCurrentPosition(function(position) {
					var
						address ='',
						geocoder = new google.maps.Geocoder,
						geolocate = new google.maps.LatLng( position.coords.latitude, position.coords.longitude ) ;

					geocoder.geocode({ 'location' : geolocate }, function( results, status ) {
						if( status === 'OK' ) {
							address = results[1].formatted_address;
							$( '[name="radius_key"]' ).val( address );
							$( '.javo-geoloc-slider' ).trigger( 'set' );
						}else{
							alert( strings.geolocation_fail );
						}
					});
				});

			} );

			$( '.dropdown-menu', near_me ).on( 'click', function( event ) {
				event.stopPropagation();
			} );

			$( '[data-close]', near_me ).on( 'click', function() {
				near_me.removeClass( 'show open' );
				$( this ).closest( '.dropdown-menu' ).removeClass( 'show open' );
			} );


		},

		objToArray : function( data ) {
			var result = new Array();
			$.each( data, function( i, r ) {
				result.push( data[ i ] );
			});
			return result;
		},

		side_out: function() {
			var panel = $( ".javo-maps-favorites-panel" );
			var btn = $( ".javo-mhome-sidebar-onoff" );
			var panel_x = -( panel.outerWidth() ) + 'px';
			var btn_x = 0 + 'px';

			panel.clearQueue().animate({ marginLeft: panel_x }, 300);
			btn.clearQueue().animate({ marginLeft: btn_x }, 300);
		},

		side_move: function() {
			var panel	= $( ".javo-maps-favorites-panel");
			var btn		= $( ".javo-mhome-sidebar-onoff" );
			var panel_x	=  0 + 'px';
			var btn_x	=  panel.outerWidth() + 'px';
			panel	.clearQueue().animate({ marginLeft: panel_x }, 300);
			btn		.clearQueue().animate({ marginLeft: btn_x }, 300);
		},

		compare : function( orderBy ) {
			var obj = this;
			return function( a, b ){
				if( obj.args.panel_list_random == 'enable' ) {
					orderBy = 'random';
				}

				switch( orderBy ) {
					case 'random' : return Math.floor( ( Math.random() * ( 1 +1 + 1 ) ) -1 );
					case 'name': return a.post_title < b.post_title ? -1 : a.post_title > b.post_title ? 1: 0; break;
					case 'favorite': return parseInt( a.save_count || 0 ) > parseInt( b.save_count || 0 ) ? -1 : parseInt( a.save_count || 0 ) < parseInt( b.save_count || 0 ) ? 1: 0; break;
					case 'date': default: return false;
				}
			}
		},

		apply_order: function( data ) {
			var
				result = [],
				o = $( "input[name='map_order[orderby]']:checked" ).closest( 'label' ).data( 'order' ),
				t = $( "input[name='map_order[orderby]']:checked" ).val();

			result = this.objToArray( data );
			result.sort( this.compare( t ) );

			if( o.toLowerCase() == 'desc' ) {
				result.reverse();
			}
			return result;
		},

		marker_on_list: function( e ){
			e.preventDefault();

			var obj = window.jvbpd_map_box_func;

			obj.marker_trigger( $(this).data('id') );

			if( obj.click_on_marker_zoom )
				obj.map.setZoom( obj.click_on_marker_zoom );
		},

		marker_trigger: function( marker_id ){
			this.el.gmap3({
				get:{
					name		: "marker"
					, id		: marker_id
					, callback	: function(m){
						google.maps.event.trigger(m, 'click');
					}
				}
			});
		}, // End Cluster Trigger

		trigger_location_keyword : function() {
			var obj		= this;
			return function( e ) {

				if( e.keyCode == 13 )
				{
					$( "input#javo-map-box-location-ac" ).val( $( this ).val() ) ;
					obj.setGetLocationKeyword( { keyCode:13, preventDefault: function(){} } );
				}
			}
		},

		setGetLocationKeyword: function( e ) {
			var
				obj					= window.jvbpd_map_box_func
				, data				= obj.items
				, el				= $("input#javo-map-box-location-ac")
				, distance_slider	= $( ".javo-geoloc-slider" );

			$( "#javo-map-box-location-trigger" ).val( el.val() );

			if( e.keyCode == 13 ){

				if( el.val() != "" ) {
					distance_slider.trigger( 'set' );
				}else{
					obj.filter( data );
				}
				e.preventDefault();
			}
		},

		setCompareDistance : function ( p1, p2 ) {
			// Google Radius API
			var R = 6371;
			var dLat = (p2.lat() - p1.lat()) * Math.PI / 180;
			var dLon = (p2.lng() - p1.lng()) * Math.PI / 180;
			var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
			Math.cos(p1.lat() * Math.PI / 180) * Math.cos(p2.lat() * Math.PI / 180) *
			Math.sin(dLon / 2) * Math.sin(dLon / 2);
			var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
			var d = R * c;
			return d;
		},

		getMyPosition : function() {
			var
				obj = this,
				distance_slider	= $( ".javo-geoloc-slider" );
			return function( e ) {
				var input			= $( '.javo-location-search' );
				obj.el.gmap3({
					getgeoloc		: {
						callback	: function( latlng ) {

							if( !latlng ){
								// $.jvbpd_msg({content: ERR_LOC_ACCESS, button: BTN_OK });
								alert( ERR_LOC_ACCESS );
								return false;
							};

							$( this ).gmap3({
								getaddress:{
									latLng		: latlng,
									callback	: function( results ) {
										var strValue		= results && results[1].formatted_address;
										input.val( strValue );
										distance_slider.trigger( 'set' );
										$( document ).trigger( 'javo:myposUpdate', strValue );
									}
								}
							});

						}	// Callback
					}	// Get Geolocation
				});
			}
		},

		currentBoundSearch : function() {

			var self = this;
			return function() {

				var
					results = new Array(),
					bounds = self.map.getBounds();

				$.each( self.items, function( i, k ){

					if( bounds.contains( new google.maps.LatLng( k.lat, k.lng ) ) ) {
						results.push( self.items[i] );
					}
				} );

				self.filter( results );
			}
		},
		doing : function() {
			return function( e ) {
				e.preventDefault();
			}
		}

		, control_manager : function( block ) {
			var
				obj					= this;
			return function() {
				obj.map_control( block );
				obj.list_control( block );
			}
		}

		, map_control : function( block ){
			var
				obj = this,
				container		= $( '.javo-maps-search-wrap' ),
				distanceBar	= container.find( '.javo-geoloc-slider' ),
				input			= container.find( 'input' ),
				dropdown	= container.find( 'select' ),
				buttons		= container.find( 'button' ),
				toggleBtn	= container.find( '.javo-map-box-filter-items span' ),
				geoButton	= container.find( '.javo-my-position' ),
				elements		= new Array(
					distanceBar,
					input,
					toggleBtn,
					buttons,
					geoButton
				);

			dropdown.each( function( index, element ) {
				var objSelect	= element.selectize;

				if( typeof objSelect == 'undefined' )
					return;

				if( block ) {
					objSelect.disable();
				}else{
					objSelect.enable();
				}
			} );

			for( var element in elements ) {
				elements[ element ].attr( 'disabled', block );
				if( block ){
					elements[ element ].addClass( 'disabled' );
				}else{
					elements[ element ].removeClass( 'disabled' );
				}
			}

			$( '.module[data-post-id] .javo-infow-brief' ).on( 'click', function( e ) {
				var
					modal = $( '#javo-infow-brief-window' ),
					body = $( '.modal-body', modal ),
					button = $( this ),
					item_id = button.closest( '.module' ).data( 'post-id' );
				obj.waitButton( button, false );
				obj.ajax( 'map_brief', { post_id: item_id }, function( data ) {
					body.html( data.html ).scrollTop(0);
					modal.off( 'shown.bs.modal' ).on( 'shown.bs.modal', function() {
						obj.preview_map( body );
						/*
						this.$element     = $(this);
						this.$content     = this.$element.find('.modal-content');

						var borderWidth   = this.$content.outerHeight() - this.$content.innerHeight();
						var dialogMargin  = $(window).width() < 768 ? 20 : 60;
						var contentHeight = $(window).height() - (dialogMargin + borderWidth);
						var headerHeight  = this.$element.find('.modal-header').outerHeight() || 0;
						var footerHeight  = this.$element.find('.modal-footer').outerHeight() || 0;
						var maxHeight     = contentHeight - (headerHeight + footerHeight);

						this.$content.css({
							'overflow': 'hidden'
						});

						this.$element
							.find('.modal-body').css({
							'max-height': maxHeight,
							'overflow-y': 'auto'
						}); */

					} );
					modal.modal( 'show' );
					obj.waitButton( button, true );
				} );
			} );

		},

		preview_map : function( container ) {
			var
				obj = this,
				map = $( '.preview-map-container', container ),
				latLng = new google.maps.LatLng( map.data( 'lat' ) || 0, map.data( 'lng' ) || 0 );

			map.height(300).gmap3({
				map: {
					options: {
						'center' : latLng,
						'zoom' : 16
					}
				},
				marker: {
					'latLng' :  latLng,
					options: {
						'icon' : obj.args.map_marker
					}
				}
			});

		},

		list_control : function( block ){
			var
				container = $( '.jvbpd_map_list_sidebar_wrap' ),
				distanceBar	= container.find( '.javo-geoloc-slider' ),
				input = container.find( 'input' ),
				dropdown = container.find( 'select'),
				buttons = container.find( 'button' ),
				geoButton = container.find( '.javo-my-position' ),
				elements = new Array(
					distanceBar,
					input,
					dropdown,
					buttons,
					geoButton
				);

			for( var element in elements ) {
				elements[ element ].attr( 'disabled', block );
				if( block ){
					elements[ element ].addClass( 'disabled' );
				}else{
					elements[ element ].removeClass( 'disabled' );
				}
			}
			$( '[data-toggle="tooltip"]' ).tooltip();

		},

		moduleLink : function() {
			var
				obj = this,
				type = obj.args.link_type,
				_marker = obj.args.map_marker_hover,
				moduleID	= 0,
				markerInfo	= {},
				callback = function( _this ) {
					return function() {

						var currentModule = _this ? $( this ).data( 'post-id' ) : $( this ).closest( '.module[data-post-id]' ).data( 'post-id' );

						if( moduleID == currentModule )
							return;

						if( moduleID ){
							obj.swapIcon( moduleID, markerInfo.icon, markerInfo.zIndex );
							$( document ).trigger( 'javo:marker_restore', { module_id : moduleID, constructor : obj } );
						}

						moduleID = currentModule;
						markerInfo	= obj.getMarker( moduleID );

						if( obj.click_on_marker_zoom )
							obj.map.setZoom( obj.click_on_marker_zoom );

						obj.swapIcon( currentModule, _marker, 9999, !_this );
						$( document ).trigger( 'javo:marker_release', { module_id : moduleID, constructor : obj } );
					}
				};

			/* Fixed */
			type = 'type3';

			if( type == 'type2' ) {
				$( document ).on ( 'hover', '.module[data-post-id]', callback( true ) );
			}else if( type == 'type3'  ) {
				$( document ).on( 'click', '.module[data-post-id] .move-marker', callback() );
			}
		}

		, getMarker : function( id ) {
			var strReturn		= { icon : false, zIndex : 0 };
			this.el.gmap3({
				get:{ name: 'marker', id:	'mid_' + id, callback : function( marker ) {
					if( !marker )
						return;
					strReturn.icon		= marker.getIcon();
					strReturn.zIndex	= marker.getZIndex();
				}}
			});
			return strReturn;
		}

		, swapIcon : function( id, url, posZ, popup ){
			var
				obj			= this
				, map		= obj.map;
			this.el.gmap3({
				get:{ name: 'marker', id:	'mid_' + id, callback : function( marker ) {
					if( !marker )
						return;
					// marker.setIcon( url );

					if( posZ !== false )
						marker.setZIndex( posZ );

					if( ! map.getBounds().contains( marker.getPosition() ) )
						map.setCenter( marker.getPosition() );

					if( popup )
						new google.maps.event.trigger( marker, 'click' );
				}}
			});
		},

		getStyles : function() {
			var
				primary_color = obj.args.map_primary_color,
				arrStyle = obj.args.map_style_json;

			if( typeof arrStyle != 'undefined' && arrStyle != '' )
				return JSON.parse( arrStyle );
			return [{featureType:"all",elementType:"all",stylers:[{color:"#c0e8e8"}]},{featureType:"administrative",elementType:"labels",stylers:[{color:"#4f4735"},{visibility:"simplified"}]},{featureType:"landscape",elementType:"all",stylers:[{color:"#e9e7e3"}]},{featureType:"poi",elementType:"labels",stylers:[{color:"#fa0000"},{visibility:"off"}]},{featureType:"road",elementType:"labels.text.fill",stylers:[{color:"#73716d"},{visibility:"on"}]},{featureType:"road.highway",elementType:"all",stylers:[{color:"#ffffff"},{weight:"0.50"}]},{featureType:"road.highway",elementType:"labels.icon",stylers:[{visibility:"off"}]},{featureType:"road.highway",elementType:"labels.text.fill",stylers:[{color:"#73716d"}]},{featureType:"water",elementType:"geometry.fill",stylers:[{color:"#7dcdcd"}]}];

		},

		waitButton : function( button, available ) {
			var _DISABLE = 'disabled';
			if( available ) {
				$( 'i', button ).removeClass( 'fa-spinner fa-spin' );
				button.removeClass( _DISABLE ).removeAttr( _DISABLE ).prop( _DISABLE, false );
			}else{
				$( 'i', button ).addClass( 'fa-spinner fa-spin' );
				button.addClass( _DISABLE ).attr( _DISABLE, _DISABLE ).prop( _DISABLE, true );
			}
		},

		ajax : function( _action, _param, callback, failcallback ) {
			var param = $.extend( true, {}, { action: 'jvbpd_' + _action }, _param );
			$.post( this.ajaxurl, param, function( data ) {
				if( typeof callback == 'function' ) {
					callback( data );
				}
			}, 'json')
			.fail( function( xhr, err ){
				if( typeof failcallback == 'function' ) {
					failcallback( xhr, err );
				}
			} );
		},

		info_window_events : function() {
			var
				obj = this,
				modal = $( '#javo-infow-brief-window' ),
				body = $( '.modal-body', modal );
			return function() {
				$( '.javo-infow-brief', obj.el ).on( 'click', function( e ) {
					var
						button = $( this ),
						item_id = button.data( 'id' );

					obj.waitButton( button, false );
					obj.ajax( 'map_brief', { post_id: item_id }, function( data ) {
						body.html( data.html );
						modal.modal( 'show' );
						obj.waitButton( button, true );
					} );
				} );
				$( '.javo-infow-contact', obj.el ).on( 'click', function( e ) {
					var button = $( this );

					obj.waitButton( button, false );
					obj.ajax( 'map_contact_form', {}, function( data ) {
						body.html( data.html );
						modal.modal( 'show' );
						obj.waitButton( button, true );
						obj.after_ajax_contactForm_rebind( body );
					} );
				} );
			}
		},

		after_ajax_contactForm_rebind : function( container ) {
			if( typeof $.fn.wpcf7InitForm == 'function' ) {
				$( 'div.wpcf7 > form', container ).wpcf7InitForm();
			}
		}
	}

	var obj = window.jvbpd_map_box_func || {};

	obj.amenities_filter = function( _terms ) {
		var
			buff = { map: '', list: '' },
			amenities_wrap =  $( '.amenities-filter-area' );

		amenities_wrap.html( '<div class="col-md-12">' + $( "#javo-map-loading-template" ).html() + '</div>' );
		$.post( obj.ajaxurl, {
			action: 'lava_lv_listing_manager_get_amenities_fields',
			terms : _terms,
			object_id : 0
		}, function( xhr ) {

			if( 0 < xhr.output.length ) {
				$.each( xhr.output, function( intDataID, MetaData ) {
					amenities_wrap.each( function( intElementID, element ) {
						var template;
						if( $( this ).hasClass( 'list-type' ) ) {
							template = '<div class="checkbox"><label><span class="check"></span><input type="checkbox" name="jvbpd_list_multiple_filter" value="{val}" data-tax="listing_amenities" data-title="{label}" class="tclick" {checked}>{label}</label></div>';
						}else{
							template = '<div class="col-md-4 col-sm-6 filter-terms"><label><input type="checkbox" name="jvbpd_map_multiple_filter" value="{val}" data-tax="listing_amenities" data-title="{label}"{checked}>{label}</label></div>';
						}

						template = template.replace( /{val}/g, MetaData.term_id || 0 );
						template = template.replace( /{label}/g, MetaData.name || '' );
						template = template.replace( /{checked}/g, ( MetaData.checked ? ' checked="checked"' : '' ) );
						if( $( this ).hasClass( 'list-type' ) ) {
							buff.list += template;
						}else{
							buff.map += template;
						}
					} );
				} );

				amenities_wrap
					.html( buff.map )
					.filter( '.list-type' )
					.html( buff.list );

				$( 'input[name="jvbpd_map_multiple_filter"]' ).on( 'click', function() {
					obj.filter();
				} );

			}else {
				amenities_wrap.html( '<div class="col-md-12">' + xhr.empty + '</div>' );
			}
			$( document ).trigger( 'javo:map_createMark' );
		}, 'JSON' );
	}

	obj.append_function = function() {
		$( ".javo-selectize-option" )
			.selectize({ maxItems:3, plugins: ['remove_button'] })
			.each(
				function( i, element ){
					var selectized	= element.selectize;
					selectized.on( 'change', function() {
						if( $( element ).is( '[data-tax="listing_category"]' ) ) {
							obj.amenities_filter( $( element ).val() );
						}

						if(  $( '#javo-map-box-location-ac' ).val() ) {
							$( '.javo-geoloc-slider' ).trigger( 'set' );
						}else{
							obj.filter();
						}

					});
					$( document ).on( 'javo:filter_reset', function() {
						selectized.clear();
					} );

				}
			);

		obj.amenities_filter();

		// $( ".javo-map-box-advance-filter-wrap" ).sticky({ topSpacing: 150 });


		// Extend Filters Trigger
		$( document )
			.on( 'javo:map_createMark', function( e ){
				var
					container = $( ".javo-maps-advanced-filter-wrap" )
					, filters = $( ".javo-map-box-filter-items" )
					, meta = $( "select", container )
					, strX = '&times;'
					, keyword = $( "#javo-map-box-auto-tag", container )
					, taxonomy = {}
					, output = new Array();

					e.preventDefault();

					/* KeyWord */ {
						if( keyword.val() ) {
							output.push( "<span data-dismiss-filter='keyword'>Keyword " + strX + "</span>" );
						}
					}

					/* Meta Dropdown */ {
						$.each( meta, function( i, k ) {
							var
								name		= $( this ).data( 'name' ),
								filterID	= $( this ).data( 'metakey' );

							if( $( this ).val() )
								output.push(
									"<span data-dismiss-filter='" + filterID + "'> " +
									name + ' ' + strX + "</span>"
								);

						} );
					}

					/* Mutiple Fileter Toogle */ {
						$( "[name='jvbpd_map_multiple_filter']").each( function()
						{
							if( $( this).is( ':checked' ) )
								taxonomy[ $( this ).data( 'title' ) ] = $( this ).data('tax');
						});

						$.each( taxonomy, function( tax_name, tax_id ) {
							output.push( "<span data-dismiss-filter=\"" + tax_id + "\">" );
							output.push( tax_name + " &times;" );
							output.push( "</span>" );
						} );
					}

					filters.html( output.join('&nbsp;') );
			} )
			.on(
				"click"
				, "#javo-map-box-advance-filter"
				, function( e, f ) {

					var
						panel			= $( ".javo-maps-search-wrap" ),
						output		= $( ".javo-maps-panel-list-output" ),
						advanced	= $( ".javo-maps-advanced-filter-wrap" ),
						button		= $( ".javo-map-box-advance-filter-apply" );

					e.preventDefault();

					f = f || false;

					if( ! this._run ) {
						advanced.hide();
						button.hide();
						this._run = true;
					}

					if( panel.hasClass( 'collapsed' ) ) {
						button.hide( 'fast' );
						advanced.slideUp( 'fast' );
						panel.removeClass( 'collapsed' );
						output.removeClass( 'hidden' );
						if( obj.panel.hasClass( 'map-layout-top' ) ) {
							$( document ).trigger( 'javo:map_createMark' );

							if( ! f )
								obj.filter();
						}
					}else{
						advanced.slideDown(
							'fast'
							, function(){
								button.show();
							}
						);
						panel.addClass( 'collapsed'  );
						output.addClass( 'hidden' );
					}
					obj.resize();
					$( '.javo-maps-panel-wrap' ).trigger( 'scroll' );
					return;
				}
			)
			.on(
				'click'
				, '.javo-map-box-btn-advance-filter-apply'
				, function( e )
				{
					e.preventDefault();
					$( document ).trigger( 'javo:map_createMark' );
					$( "#javo-map-box-advance-filter" ).trigger( 'click' );
					if( $( "#javo-map-box-location-ac" ).val() ) {
						$( '.javo-geoloc-slider' ).trigger( 'set' );
					}else{
						obj.filter();
					}
					return;
				}
			)
			.on(
				'click'
				, '[data-dismiss-filter]'
				, function( e )
				{
					e.preventDefault();

					var
						eID				= $( this ).data( 'dismiss-filter' )
						, selector		= null
						, container	= $( ".javo-maps-advanced-filter-wrap" )

					switch( eID ) {
						case 'keyword' :
							/* Keyword */ {
								selector	= $( '#javo-map-box-auto-tag', container );
								selector.val( '' );
							}
							break;

						case 'price' :

							selector		= $( "[data-min], [data-max]", container );
							selector.val( '' );
							break;

						default:
							/* Multiple Filter Unset */ {
								selector	= $( "[name='jvbpd_map_multiple_filter'][data-tax='" + eID + "']" );
								selector.prop( 'checked', false );
							}
							/* Dropdown Filter Unset */ {
								selector	= $( "select[data-metakey='" + eID + "']" );
								selector.val('');
								if( typeof selector[0] != 'undefined' ) {
									var selectize = selector[0].selectize;
									selectize.clear();
								}
							}
					}

					$( this ).remove();
					if( $( "#javo-map-box-location-ac" ).val() ) {
						$( '.javo-geoloc-slider' ).trigger( 'set' );
					}else{
						obj.filter();
					}
					return;
				}
			)
			.on(
				'click'
				, '#javo-map-box-advance-filter-reset'
				, function (e)
				{
					$( "#javo-map-box-location-ac" ).val();

					$( document )
						.trigger( 'javo:map_refresh' )
						.trigger( 'javo:filter_reset');

				}
			)
			.on(
				'click'
				, '.javo-map-box-advance-filter-trigger'
				, function( e )
				{
					e.preventDefault();
					$( "#javo-map-box-advance-filter" ).trigger( 'click' );
				}
			);
	}

	obj.selectize_filter = function( data, el, taxonomy ) {
		var result	= [], term	= {}, values = [];

		if( el.val() ){
			$.each( data,
				function( i, k ) {
					values = typeof el.val() == 'string' ? new Array( el.val() ) :  el.val();
					$.each( values,
						function( index, term_ids )
						{
							if( typeof k[ taxonomy ] != "undefined" ) {
								if( k[ taxonomy ].indexOf( term_ids ) > - 1 ){
									result.push( data[i] );
									return false;
								}
							}
						}
					);
				}
			);
		}else{
			result = data;
		}

		return result;
	}

	obj.price_filter		= function( data ) {
		var
			results
			, container	= $( ".javo-maps-advanced-filter-wrap" )
			, price			= $( ".javo-map-box-advance-pricefilter", container )
			, min				= parseInt( $( "[data-min]", price ).val() )
			, max			= parseInt( $( "[data-max]", price ).val() );

		if( !isNaN( min ) && min > 0 ) {
			results			= [];
			$.each( data, function( index, arrMeta ) {
				var price	= parseInt( arrMeta._price );
				if( !isNaN( price ) && ( price >= min ) )
					results.push( data[index] );
			} );
			data				= results;
		}

		if( !isNaN( max ) && max > 0 ) {
			results			= [];
			$.each( data, function( index, arrMeta ) {
				var price	= parseInt( arrMeta._price );
				if( !isNaN( price ) && ( price <= max ) )
					results.push( data[index] );
			} );
			data				= results;
		}
		return data;
	}


	obj.extend_filter	= function( items ) {
		$.each( obj.args.selctize_terms, function( i, tax_selector ){
			// items = obj.selectize_filter( items, $( "[name='map_filter[" + tax_selector + "]']" ), tax_selector );
			if( tax_selector != 'listing_category' ) {
				items = obj.selectize_filter( items, $( ".shortcode-jvbpd_search1 select[data-tax=" + tax_selector + "]" ), tax_selector );
			}
		} );
		items	 = obj.price_filter( items );
		return items;
	}

	$( '.javo-maps-panel-wrap' ).on(
		'scroll'
		, function(){

			var
				container			= $( this )
				, container_offset	= container.offset().top
				, filter			= $( '.javo-map-box-advance-filter-wrap' )
				, filter_offset		= filter.offset().top;

		}
	);

	$( document ).on( 'javo:map_updated', function( event, items ) {
		var
			element = $( '.control-panel-in-map .total-count .count' ),
			output = '';

		output += items.length || 0;
		output += ' ' + element.data( 'suffix' );
		element.html( output );
	} );

window.jvbpd_map_box_func.init();

var jvbpd_multi_listing = function(){

	if( ! window.__LAVA_MULTI_LISTINGS__ )
		this.init();
}

jvbpd_multi_listing.prototype = {

	constructor : jvbpd_multi_listing,

	init : function() {
		window.__LAVA_MULTI_LISTINGS__ = 1;

		this.args = jvbpd_core_map_param;

		this.showListings();
		this.innerSwitch();
		this.setCommonAction();

		$( document )
			.on( 'javo:apply_sticky'		, this.setStickyContainer() )
			.on( 'javo:map_updated'	, this.showResult() );

		if( $( 'body' ).hasClass( 'mobile-ajax-top' ) )
			$( document ).on( 'javo:map_template_reisze', this.mobileFilter() );

		$( '.javo-maps-panel-wrap' ).on( 'scroll', this.stickyOnPanel() );

		$( document ).ready(  this.setStickyContainer() );
	},

	setStickyContainer : function() {
		return function() {
			if( $( "#javo-mhome-item-info-wrap" ).length ) {
				$( "#javo-mhome-item-tabs-navi" ).sticky({
					topSpacing: $( ".javo-mhome-item-info-wrap" ).offset().top
				});
			}
		}
	},

	stickyOnPanel : function() {
		var obj = this;
		return function() {
			var
				panel						= $( ".javo-maps-panel-wrap" )
				, button					= $( "#javo-map-box-advance-filter", panel )
				, container				= $( ".javo-map-box-advance-filter-wrap" )
				, sticked_container	= $( ".javo-map-box-advance-filter-wrap-fixed" )
				, container_offset		=	container.offset().top;

			sticked_container.css({
				top		: panel.offset().top,
				width	: panel.width()
			}).hide();

			if( container_offset < 0 )
			{
				if( !obj.sticked ){
					container.children().appendTo( sticked_container );
					obj.sticked	= true;
				}
				sticked_container.show();
			}else{
				if( obj.sticked ){
					sticked_container.children().appendTo( container );
					obj.sticked	= false;
				}
			}
		}
	},

	showResult : function () {
		return function ( event, items ) {
			var
				output		= $( ".javo-maps-panel-list-output #products > .row" )
				, template	= $( "#javo-map-not-found-data" ).html();

			if( ! items.length )
				output.html( template );
		}
	},

	showListings : function() {
		var
			obj			= this
			, elements	= $( "#javo-maps-wrap, #javo-listings-wrap" )
			, switcher	= "[type='radio'][name='m']"
			, callback	= function( e ) {
				e.preventDefault();
				var type = $( switcher + ":checked" ).val();

				elements.addClass( 'hidden' );
				$( "#javo-" + type + '-wrap' ).removeClass( 'hidden' );
				obj.process( type );

				$( ".javo-maps-area" ).gmap3({ trigger: 'resize' }, 'autofit' );
				return;
			}
		callback({ preventDefault:function(){} });
		$( document ).on( 'change', switcher, callback );
	},


	innerSwitch : function() {

		var
			container = $( '#javo-maps-listings-wrap' ),
			switcher_wrap = $( '.javo-map-box-inner-switcher' ),
			map_wrap = $( '#javo-maps-wrap', container ),
			inner_switcher = $( '> button', switcher_wrap ),
			map_area = $( '.javo-maps-area-wrap', map_wrap ),
			panel_area = $( '.javo-maps-panel-wrap', map_wrap );

		inner_switcher.on( 'click', function() {

			var strType = $( '.hidden', this ).data( 'value' );

			$( this ).data( 'value', strType );
			$( 'span', this ).addClass( 'hidden' );
			$( 'span[data-value="' + strType + '"]' ).removeClass( 'hidden' );

			if( strType == 'map' ){
				map_area.addClass( 'mobile-active' ).find( '.javo-maps-area' ).gmap3({ trigger: 'resize' }, 'autofit' );
				panel_area.removeClass( 'mobile-active' );
			}else{
				map_area.removeClass( 'mobile-active' );
				panel_area.addClass( 'mobile-active' );
			}

		} ).trigger( 'click' );
	},


	mobileFilter : function() {

		var
			obj = this,
			minMoved = false,
			maxMoved = false,
			panel = $( '.javo-maps-panel-wrap' ),
			filter_wrap = $( '.javo-maps-search-wrap', panel ),
			filters = $( '> .row:not(.javo-map-box-advance-filter-wrap)', filter_wrap ),
			advance_filters = $( '.javo-maps-advanced-filter-wrap', filter_wrap );

		// Disable oneline-type
		if( panel.hasClass( 'jv-map-filter-type-bottom-oneline' ) )
			return false;

		return function( e, width ){

			if( parseInt( width ) < 767 ) {

				if( ! minMoved ){
					filters.prependTo( advance_filters );
					minMoved = true;
				}
				maxMoved = false;
			}else{
				if( ! maxMoved ){
					filters.prependTo( filter_wrap );
					maxMoved = true;
				}
				minMoved = false;
			}
		}

	}


	, setCommonAction : function()
	{
		var
			obj = window.jvbpd_map_box_func
			, listing = $( '#javo-listings-wrap' )
			, map = $( '#javo-maps-wrap' )
			, term_elements	= "#javo-listings-wrap [name='jvbpd_list_multiple_filter']"
			, price_elements	= $( '#filter-price [data-min], #filter-price [data-max]', listing )
			, key_elements		= $( '#filter-keyword input.jv-keyword-trigger', listing )
			, mypos_trigger	= $( 'button.my-position-trigger', listing )
			, option_elements	= $( "#filter-options [data-metakey]", listing );


		$( document )

		// Multiple Checkbox Filter Trigger
			.on( 'click', term_elements,
				function( e )
				{
					var tax = $( this ).val();

					if( $( this ).is( ":checked" ) ){
						$( "[name='jvbpd_map_multiple_filter'][value='" + tax +  "'], [name='jvbpd_list_multiple_filter'][value='" + tax +  "']" ).prop( 'checked', true );
					}else{
						$( "[name='jvbpd_map_multiple_filter'][value='" + tax +  "'], [name='jvbpd_list_multiple_filter'][value='" + tax +  "']" ).prop( 'checked', false );
					}
					obj.filter();
				}
			);

		// Listings > My Position Trigger
		mypos_trigger.on( 'click',
			function( e ){
				e.preventDefault();
				var
					mypos			= $( ".javo-my-position", map );
				mypos.trigger( 'click' );
			}
		);

		// Listings > Keyword Filter Trigger
		key_elements.on( 'keypress',
			function( e ){
				var mapKeyword	= $( "#javo-map-box-auto-tag", map );
				if( e.keyCode ==13 ) {
					mapKeyword.val( $( this ).val() );
					obj.filter();
				}
			}
		);

		// Listings > Optional Trigger
		option_elements.on( 'change',
			function( e ) {
				var target = $( "select[data-metakey='" + $( this ).data( 'metakey' ) + "']", map );
				target.val( $( this ).val() );
				if( $( "#javo-map-box-location-ac" ).val() ) {
					$( '.javo-geoloc-slider' ).trigger( 'set' );
				}else{
					obj.filter();
				}
			}
		);
	}

	, process : function( type )
	{
		var obj = this;
		window.jvbpd_map_box_func.list_type = type;
		window.jvbpd_map_box_func.resize();

	} // End Initialize Function


}

new jvbpd_multi_listing;

} )( jQuery );
