<?php
jvlynkCore()->template_instance->load_template( '../dir/templates/parts/part-mypage-user-dashboard' );
if( class_exists( 'Post_Views_Counter' ) ) {
	$arrCharItems = array_filter( (array) get_user_meta( get_current_user_id(), '_mypage_chart_items', true ) );
	jvlynkCore()->template_instance->load_template(
		'../dir/templates/parts/part-mypage-user-dashboard', '.php', Array(
			'jvbpd_aricle_args' => (object) Array(
				'label' => esc_html__( "Listing Views ( 6 Months )", 'jvfrmtd' ),
				'values' => $arrCharItems,
				'limit_month' => 6,
				'count_type' => 2,
				'graph_type' => 'line',
			),
		)
	);
}