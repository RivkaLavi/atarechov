<div class="row">
	<div class="col-md-12">

	<!-- Starting Content -->
		<div class="card listing-card">
			<div class="card-header">
				<h4 class="card-title"><?php esc_html_e( "Recent Reviews", 'jvfrmtd' ); ?></h4>
			</div>
			<ul class="list-group list-group-flush">
				<?php jvlynkCore()->template_instance->load_template( '../dir/mypage/reviews/received-content' ); ?>
			</ul>
		</div> <!-- .card -->
	<!-- Content End -->

	</div> <!-- col-md-12 -->
</div><!--/row-->