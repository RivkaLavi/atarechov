<?php

Class Jvbpd_bp_dir_ext {

	private static $Instance = null;

	public static function getInstance() {
		if( is_null( self::$Instance ) ) {
			self::$Instance = new self;
		}
		return self::$Instance;

	}

	public function __construct() {
		$this->registerHooks();
	}

	public function registerHooks() {
		add_action( 'bp_setup_nav', array( $this, 'init' ) );
	}
	public function init() {
		add_action( 'bp_setup_nav', array( $this, 'add_dashboard_tab' ), 100 );
		add_action( 'bp_setup_nav', array( $this, 'add_mylistings_tab' ), 101 );
		add_action( 'bp_setup_nav', array( $this, 'add_favorites_tab' ), 101 );
		add_action( 'bp_setup_nav', array( $this, 'add_reviews_tab' ), 101 );
		add_action( 'bp_setup_nav', array( $this, 'add_orders_tab' ), 101 );
	}

	/*** Adding listing menus **/
	public function add_dashboard_tab() {
		global $bp;
		bp_core_new_nav_item( array(
			'name'                  => esc_html__( "Home", 'jvfrmtd' ),
			'slug'                  => 'home',
			'screen_function'       => Array( $this, 'bp_index' ),
			'position'              => 1,
			'default_subnav_slug'   => 'index'
		) );

		bp_core_new_subnav_item( array(
			'name'              => esc_html__( "Index", 'jvfrmtd' ),
			'slug'              => 'index',
			'parent_url'        => trailingslashit( bp_displayed_user_domain() . 'home' ),
			'parent_slug'       => 'home',
			'screen_function'   => Array( $this, 'bp_index' ),
			'position'          => 1,
			'user_has_access'   => bp_is_my_profile()
		) );

		bp_core_new_subnav_item( array(
			'name'              => esc_html__( "Settings", 'jvfrmtd' ),
			'slug'              => 'settings',
			'parent_url'        => trailingslashit( bp_displayed_user_domain() . 'home' ),
			'parent_slug'       => 'home',
			'screen_function'   => Array( $this, 'bp_index' ),
			'position'          => 100,
			'user_has_access'   => bp_is_my_profile()
		) );

	}

	public function add_mylistings_tab() {
		global $bp;
		bp_core_new_nav_item( array(
			'name'                  => esc_html__( "Listings", 'jvfrmtd' ),
			'slug'                  => 'listings',
			'screen_function'       => Array( $this, 'bp_index' ),
			'position'              => 2,
			'default_subnav_slug'   => 'published'
		) );

		bp_core_new_subnav_item( array(
			'name'              => esc_html__( "Published", 'jvfrmtd' ),
			'slug'              => 'published',
			'parent_url'        => trailingslashit( bp_displayed_user_domain() . 'listings' ),
			'parent_slug'       => 'listings',
			'screen_function'   => Array( $this, 'bp_index' ),
			'position'          => 1,
			'user_has_access'   => bp_is_my_profile()
		) );

		bp_core_new_subnav_item( array(
			'name'              => esc_html__( "Pending", 'jvfrmtd' ),
			'slug'              => 'pending',
			'parent_url'        => trailingslashit( bp_displayed_user_domain() . 'listings' ),
			'parent_slug'       => 'listings',
			'screen_function'   => Array( $this, 'bp_index' ),
			'position'          => 100,
			'user_has_access'   => bp_is_my_profile()
		) );

		bp_core_new_subnav_item( array(
			'name'              => esc_html__( "Expired", 'jvfrmtd' ),
			'slug'              => 'expired',
			'parent_url'        => trailingslashit( bp_displayed_user_domain() . 'listings' ),
			'parent_slug'       => 'listings',
			'screen_function'   => Array( $this, 'bp_index' ),
			'position'          => 100,
			'user_has_access'   => bp_is_my_profile()
		) );

	}

	public function add_favorites_tab() {
		global $bp;
		bp_core_new_nav_item( array(
			'name'                  => esc_html__( "Favorites", 'jvfrmtd' ),
			'slug'                  => 'favorites',
			'screen_function'       => Array( $this, 'bp_index' ),
			'position'              => 3,
			'default_subnav_slug'   => 'index'
		) );

		bp_core_new_subnav_item( array(
			'name'              => esc_html__( "Index", 'jvfrmtd' ),
			'slug'              => 'index',
			'parent_url'        => trailingslashit( bp_displayed_user_domain() . 'favorites' ),
			'parent_slug'       => 'favorites',
			'screen_function'   => Array( $this, 'bp_index' ),
			'position'          => 1,
			'user_has_access'   => bp_is_my_profile()
		) );
	}

	public function add_reviews_tab() {
		global $bp;
		bp_core_new_nav_item( array(
			'name'                  => esc_html__( "Reviews", 'jvfrmtd' ),
			'slug'                  => 'reviews',
			'screen_function'       => Array( $this, 'bp_index' ),
			'position'              => 4,
			'default_subnav_slug'   => 'received'
		) );

		bp_core_new_subnav_item( array(
			'name'              => esc_html__( "Received", 'jvfrmtd' ),
			'slug'              => 'received',
			'parent_url'        => trailingslashit( bp_displayed_user_domain() . 'reviews' ),
			'parent_slug'       => 'reviews',
			'screen_function'   => Array( $this, 'bp_index' ),
			'position'          => 1,
			'user_has_access'   => bp_is_my_profile()
		) );

		bp_core_new_subnav_item( array(
			'name'              => esc_html__( "Submitted", 'jvfrmtd' ),
			'slug'              => 'submitted',
			'parent_url'        => trailingslashit( bp_displayed_user_domain() . 'reviews' ),
			'parent_slug'       => 'reviews',
			'screen_function'   => Array( $this, 'bp_index' ),
			'position'          => 100,
			'user_has_access'   => bp_is_my_profile()
		) );

	}

	public function add_orders_tab() {
		global $bp;
		bp_core_new_nav_item( array(
			'name'                  => esc_html__( "Orders", 'jvfrmtd' ),
			'slug'                  => 'orders',
			'screen_function'       => Array( $this, 'bp_index' ),
			'position'              => 5,
			'default_subnav_slug'   => 'index'
		) );

		bp_core_new_subnav_item( array(
			'name'              => esc_html__( "Orders", 'jvfrmtd' ),
			'slug'              => 'index',
			'parent_url'        => trailingslashit( bp_displayed_user_domain() . 'orders' ),
			'parent_slug'       => 'orders',
			'screen_function'   => Array( $this, 'bp_index' ),
			'position'          => 100,
			'user_has_access'   => bp_is_my_profile()
		) );

	}

	public function bp_index() {
		/*
		$fucName = sprintf( 'bp_page_%s_%s', BuddyPress()->current_component, BuddyPress()->current_action );
		$fnCallback = array( $this, $fucName );
		if( is_callable( $fnCallback ) ) {
			add_action( 'bp_template_content', $fnCallback );
		}**/
		add_action( 'bp_template_content', array( $this, 'bp_template_content' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'memberpage_enqueue' ) );
		bp_core_load_template( apply_filters( 'bp_core_template_plugin', 'members/single/plugins' ) );
	}

	public function memberpage_enqueue() {
		wp_enqueue_script( jvlynkCore()->var_instance->getHandleName( 'chart' ) );
	}

	public function bp_template_content() {
		$fileName = sprintf( '%1$s/dir/mypage/%2$s/%3$s.php', jvlynkCore()->path, BuddyPress()->current_component, BuddyPress()->current_action );
		if( file_exists( $fileName ) ) {
			require_once( $fileName );
		}
	}

	/** Buddypress profile pages */
	public function bp_page_home_index() {
		jvbpd_layout()->load_template( 'parts/part-mypage-user-dashboard' );
		if( class_exists( 'Post_Views_Counter' ) ) {
			$arrCharItems = array_filter( (array) get_user_meta( get_current_user_id(), '_mypage_chart_items', true ) );
			jvbpd_layout()->load_template(
				'chart-template', Array(
					'jvbpd_aricle_args' => (object) Array(
						'label' => esc_html__( "Listing Views ( 6 Months )", 'jvfrmtd' ),
						'values' => $arrCharItems,
						'limit_month' => 6,
						'count_type' => 2,
						'graph_type' => 'line',
					),
				)
			);
		}
	}
}