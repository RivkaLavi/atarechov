<div class="row">
	<div class="col-md-12">
		<div class="card listing-card">
			<div class="card-header"><h4 class="card-title"><?php esc_html_e( "Pending Listings", 'jvfrmtd' ); ?></h4></div><!-- card-header -->
			<?php jvbpd_layout()->load_file( dirname( __FILE__ ) . '/contents.php', array( 'lavaDashBoardArgs' => array( 'type' => 'pending' ) ) ); ?>
		</div><!-- /.section-block -->
	</div> <!-- col-md-12 -->
</div><!--/row-->