<div class="card-header">
	<h4 class="card-title"><?php esc_html_e('Listing Views ( 6 Months )', 'jvfrmtd'); ?></h4>
</div>
<div class="card-block" style="padding: 0 50px;">
	<div id="canvas-holder" style="width:70%;">
		<canvas id="chart-area"/>
	</div>
</div> <!-- cardblock -->