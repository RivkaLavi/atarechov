<?php
global
	$jvbpd_get_query,
	$jvbpd_post_query,
	$jvbpd_map_box_type;
get_header();
do_action( "lava_{$post->lava_type}_map_container_before", $post );
?>

			<div id="javo-maps-listings-wrap" <?php post_class(); ?>>
				<?php do_action( "jvbpd_{$post->lava_type}_map_body" ); ?>
			</div>

			<fieldset>
				<input type="hidden" name="get_pos_trigger" value="<?php echo (boolean) esc_attr( $post->req_is_geolocation ); ?>">
				<input type="hidden" name="set_radius_value" value="<?php echo esc_attr( $post->lava_current_dis ); ?>">
			</fieldset>

			<script type="text/html" id="javo-map-not-found-data">
				<div class="jvbpd_map_not_found col text-center" data-dismiss>
					<?php esc_html_e( "Not found data", 'jvfrmtd' ); ?>
				</div>
			</script>

			<?php do_action( "lava_lv_listing_map_container_after", $post ); ?>
			</div><!-- /#container-fluid( in header.php ) -->
		</div><!-- /#wrapper ( in library / header / header.php )-->
	</div><!-- /#content-page-wrapper ( in header.php ) -->
</div><!-- /#page-style ( in header.php ) -->
<?php
get_template_part( 'includes/templates/modal', 'contact-us' );
do_action( 'jvbpd_body_after', get_page_template_slug() );
wp_footer(); ?>
</body></html>