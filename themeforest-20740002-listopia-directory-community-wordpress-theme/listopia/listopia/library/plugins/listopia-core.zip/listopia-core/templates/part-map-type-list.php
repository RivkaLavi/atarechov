<?php
$arrListingFilters	= apply_filters( 'jvbpd_' . jvlynkCore()->getSlug() . '_map_list_filters', Array() );
$strListOutputClass = sprintf(
	'class="%s"', join(
		' ',
		apply_filters(
			'jvbpd_map_list_output_class',
			Array( 'javo-shortcode' )
		)
	)
); ?>
<div id="map-list-style-wrap" <?php jvbpd_map_class( 'container' ); ?>>
	<?php
	do_action( 'jvbpd_' . jvlynkCore()->getSlug() . '_map_list_wrap_before', $GLOBALS[ 'post' ] );
	// the_content();
	do_action( 'jvbpd_' . jvlynkCore()->getSlug() . '_map_list_wrap_after', $GLOBALS[ 'post' ] ); ?>
</div><!-- /.container-->