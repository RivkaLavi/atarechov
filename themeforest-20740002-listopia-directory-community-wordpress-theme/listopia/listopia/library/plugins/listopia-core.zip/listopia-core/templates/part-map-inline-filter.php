<div id="javo-maps-listings-switcher">
	<input type="radio" name="m" value="maps" checked="checked" class="hidden">
</div>