<?php
$arrPages = jvbpd_tso()->getPages(); ?>
<div class="jvbpd_ts_tab javo-opts-group-tab hidden" tar="lvdr">
	<h2> <?php esc_html_e( "Listing Settings", 'jvfrmtd' ); ?> </h2>
	<table class="form-table">
	<tr><th>
		<?php esc_html_e( "Page settings", 'jvfrmtd' );?>
		<span class="description"></span>
	</th><td>

		<h4><?php esc_html_e( "Add listing",'jvfrmtd' ); ?></h4>
		<fieldset  class="inner">
			<select name="jvbpd_ts[add_listing]">
				<option value=""><?php esc_html_e( "Select a page", 'jvfrmtd' ); ?></option>
				<?php
				foreach( $arrPages as $objPage ) {
					printf(
						'<option value="%1$s"%3$s>%2$s</option>',
						$objPage->ID, $objPage->post_title,
						selected( jvbpd_tso()->get( 'add_listing' ) == $objPage->ID, true, false )
					);
				} ?>
			</select>
		</fieldset>
	</td></tr><tr><th>
		<?php esc_html_e( "Shortcode", 'jvfrmtd' );?>
		<span class="description"></span>
	</th><td>

		<h4><?php esc_html_e( "Header search shortcode result page",'jvfrmtd' ); ?></h4>
		<fieldset  class="inner">
			<select name="jvbpd_ts[search_sesult_page]">
				<option value=""><?php esc_html_e( "Select a page", 'jvfrmtd' ); ?></option>
				<?php
				foreach( $arrPages as $objPage ) {
					printf(
						'<option value="%1$s"%3$s>%2$s</option>',
						$objPage->ID, $objPage->post_title,
						selected( jvbpd_tso()->get( 'search_sesult_page' ) == $objPage->ID, true, false )
					);
				} ?>
			</select>
		</fieldset>
	</td></tr><tr><th>
		<?php esc_html_e( "Header image", 'jvfrmtd' );?>
		<span class="description"></span>
	</th><td>

		<h4><?php esc_html_e( "Header image type to show first", 'jvfrmtd' ); ?></h4>
		<fieldset class="inner">
			<select name="jvbpd_ts[lv_listing_single_first_header]">
				<?php
				$arrSingleItemHeaderCover	= apply_filters(
					'jvbpd_lv_listing_header',
					Array(
						'' => esc_html__( "Featured image", 'jvfrmtd' ),
						'listing_category'	=> esc_html__( "Listing category featured image", 'jvfrmtd' ),
						'grid_style' => esc_html__( "Grid Style", 'jvfrmtd' ),
					)
				);
				if( !empty( $arrSingleItemHeaderCover ) )
					foreach( $arrSingleItemHeaderCover as $classes => $label ) {
						printf(
							"<option value=\"{$classes}\" %s>{$label}</option>",
							selected( jvbpd_tso()->get( 'lv_listing_single_header_cover', '' ) == $classes, true, false )
						);
					}
				?>
			</select>
		</fieldset>

	</td></tr>
	</table>
</div>