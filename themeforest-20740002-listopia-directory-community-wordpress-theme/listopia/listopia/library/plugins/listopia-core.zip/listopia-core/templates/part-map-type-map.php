<?php
// Get Item Tages
{
	$jvbpd_all_tags				= '';
	foreach( get_tags( Array( 'fields' => 'names' ) ) as $tags ) {
		$jvbpd_all_tags			.= "{$tags}|";
	}
	$jvbpd_all_tags				= substr( $jvbpd_all_tags, 0, -1 );
}

//
$strMapOutputClass = sprintf(
	'class="%s"', join(
		' ',
		apply_filters(
			'jvbpd_map_output_class',
			Array( 'list-group', 'javo-shortcode' )
		)
	)
); ?>
<div class="javo-maps-container">
	<div class="javo-maps-panel-wrap">
		<?php
		if( is_singular( 'page' ) ) {
			the_content();
		}else{
			if( function_exists( 'jvbpd_listing_achive_render' ) ){
				jvbpd_listing_achive_render();
			}
		} ?>
	</div>
	<div <?php jvbpd_map_class( 'javo-maps-area-wrap' ); ?>>
		<div class="javo-maps-area"></div>
	</div>
</div><!-- /.javo-maps-container -->

<?php

// Map Container After
do_action( 'jvbpd_'  . jvlynkCore()->getSlug() . '_map_container_after', get_the_ID() );