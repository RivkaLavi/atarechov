<section class="elementor-element jvbpd-mobile-filter-controls hidden-sm hidden-md hidden-lg">
	<div class="row">
		<div class="col-6">
			<button type="button" class="btn btn-block btn-primary jvbpd-map-filter-opener">
				<i class="fa fa-filter"></i>
				<?php esc_html_e( "Advanced Filter", 'jvfrmtd' ); ?>
			</button>
		</div>
		<div class="col-6">
			<button type="button" class="btn btn-block btn-primary">
				<i class="fa fa-refresh"></i>
				<?php esc_html_e( "Reset", 'jvfrmtd' ); ?>
			</button>
		</div>
	</div>
</section>
