<?php

printf(
	'<div style="text-align:center; letter-spacing:1px; clear:both;">
		<a href="%1$s" target="%2$s" style="text-decoration:none;"><span style="color:#666666;">%3$s&nbsp;&nbsp;<font style="color:red;">%4$s</font></span></a>
	</div>',
	esc_url( 'javothemes.com/support/free-installation/' ), esc_attr( '_blank' ),
	esc_html__( "Event for free installation and check site setting ( Save $50 ).", 'jvfrmtd' ),
	esc_html__( "APPLY NOW", 'jvfrmtd' )
);