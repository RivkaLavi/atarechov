<?php

if( ! function_exists( 'jvbpd_single_navigation' ) ) {
	function jvbpd_single_navigation(){
		return apply_filters(
			'jvbpd_detail_item_nav'
			, Array(
				'page-style'				=> Array(
					'label'					=> esc_html__( "Top", 'jvfrmtd' )
					, 'class'				=> 'glyphicon glyphicon-home'
					, 'type'				=> Array( get_post_type() )
				)
			)
		);
	}
}

if( !function_exists( 'jvbpd_has_attach' ) ) : function jvbpd_has_attach(){
	global $post;
	return !empty( $post->attach );
} endif;

if( !function_exists( 'jvbpd_get_reportShortcode' ) ) : function jvbpd_get_reportShortcode(){
	global $lava_report_shortcode;
	return $lava_report_shortcode;
} endif;

if( !function_exists( 'jvbpd_getSearch1_Shortcode' ) ) : function jvbpd_getSearch1_Shortcode(){
	global $jvbpd_search1;
	return $jvbpd_search1;
} endif;



function jvbpd_elementor_widget() {
	// Load localization file
	//load_plugin_textdomain( 'jvbpd' );

	// Notice if the Elementor is not active
	if ( ! did_action( 'elementor/loaded' ) ) {
		return;
	}

	// Check version required
	$elementor_version_required = '1.0.0';
	if ( ! version_compare( ELEMENTOR_VERSION, $elementor_version_required, '>=' ) ) {
		return;
	}

	// Require the main plugin file
	//require( __DIR__ . '/class-elementor.php' );   //loading the main plugin


}
add_action( 'plugins_loaded', 'jvbpd_elementor_widget' ); 