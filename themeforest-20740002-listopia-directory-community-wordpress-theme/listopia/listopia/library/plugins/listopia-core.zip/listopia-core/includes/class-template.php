<?php
class Lynk_Core_Template extends Lynk_Core {

	Const PREVIEW_KEY_FORMAT = 'single_%1$s_%2$s_preview_type';
	Const CORE_PREFIX_FORMAT = 'jvbpd_%s_';

	Public $prefix = 'jvbpd_';
	Public $core_prefix = '';

	Public $is_archive = false;

	Private $map_slug = '';

	Private $filter_position = false;

	Private $single_type = 'type-grid';
	Private $support_type = 'type-c';

	Public $is_review_plugin_active = false;
	Public $is_cross_domain = false;
	Public $strGetJsonHook = false;
	Public $json_file = '';

	public function __construct() {
		add_filter( 'template_include', array( $this, 'map_template' ), 99 );
		add_action( 'wp_enqueue_scripts', array( $this, 'register_scripts' ) );

		add_action( 'init', Array( $this, 'get_lava_jsonfile' ), 99 );

		$this->setVariables();
		$this->loadMapTemplate();
		$this->registerHooks();
		$this->woo_func();

		$this->loadLess();
	}

	public function map_template( $template='' ) {
		$post = get_queried_object();
		if( $post instanceof WP_Post ) {
			$template = 'lava_lv_listing_map' == get_post_meta( $post->ID, '_wp_page_template', true ) ? $this->initMapTemplate() : $template;
		}
		return $template;
	}

	public function register_scripts() {
		$scripts = Array(
			'map-template' => Array(
				'src' => 'map-template.js',
			),
			'jquery-lynk-search' => Array(
				'src' => 'jquery-lynk-search.js',
			),
			'jquery-type-header' => Array(
				'src' => 'jquery-type-header.js',
			),
			'jvbpd-listing-single' => Array(
				'src' => 'single.js',
			),
			'chart' => Array(
				'src' => 'Chart.js/Chart.min.js'
			),
			'swiper.min.js' => Array(
				'handle' => 'swiper',
				'src' => 'swiper.min.js',
			),
		);

		if( !empty( $scripts ) ) {
			foreach( $scripts as $script => $scriptMeta ) {

				$deps = Array( 'jquery' );
				if( isset( $scriptMeta[ 'deps' ] ) ) {
					$deps = wp_parse_args( $deps, $scriptMeta[ 'deps' ] );
				}

				$ver = jvlynkCore()->getVersion();
				if( isset( $scriptMeta[ 'ver' ] ) ) {
					$ver = $scriptMeta[ 'ver' ];
				}

				wp_register_script(
					( isset( $scriptMeta[ 'handle' ] ) ? $scriptMeta[ 'handle' ] : jvlynkCore()->var_instance->getHandleName( $script ) ),
					jvlynkCore()->assets_url . 'js/' . $scriptMeta[ 'src' ],
					$deps, $ver, true
				);
			}
		}
	}

	public function get_lava_jsonfile() {
		if( !function_exists( 'lava_directory' ) )
			return;

		if( method_exists( lava_directory()->core, 'getJsonFileName' ) )
			$this->json_file = lava_directory()->core->getJsonFileName();

		if( method_exists( lava_directory()->core, 'is_crossdomain' ) ) {
			$this->is_cross_domain = lava_directory()->core->is_crossdomain();
			$this->strGetJsonHook = sprintf( 'lava_%s_get_json', self::CORE_POST_TYPE );
		}
	}

	public function initMapTemplate() {
		return parent::$instance->template_path . '/template-map.php';
	}

	public function loadMapTemplate() {
		// add_action( 'jvbpd_' . parent::CORE_POST_TYPE . '_map_body', Array( $this, 'load_map_type_switcher' ) );
		add_action( 'jvbpd_' . parent::CORE_POST_TYPE . '_map_body', Array( $this, 'load_map_inline_filter' ) );
		add_action( 'jvbpd_' . parent::CORE_POST_TYPE . '_map_body', Array( $this, 'custom_load_map' ) );
		add_action( 'lava_' . parent::CORE_POST_TYPE . '_map_container_after', Array( $this, 'custom_map_scripts' ) );
	}



	public function setVariables() {
		$this->map_slug = 'multipleBox';
		$this->slug = self::CORE_POST_TYPE;
		self::$instance = &$this;
		$this->core_prefix = sprintf( self::CORE_PREFIX_FORMAT, parent::CORE_POST_TYPE );
	}

	public function registerHooks() {
		// Get Json File Name
		add_action( 'init', Array( $this, 'active_hooks' ), 11 );
		add_action( 'wp_head', Array( $this, 'active_hooks' ) );
		add_action( 'wp_enqueue_scripts', Array( $this, 'single_hooks' ) );
		add_action( 'save_post', Array( $this, 'setSingleType' ), 10, 2 );

		// Single
		add_filter( 'template_include', Array( $this, 'single_template' ), 15 );

		add_filter( 'wp_nav_menu_items', Array( $this, 'addHeaderSearchMenu' ), 10, 2 );

	}

	public function setCoreSingleType() {
		$arrTypes = Array(
			'type-a',
			'type-b',
			'type-half',
			'type-grid',
			'type-left-tab',
			'type-top-tab'
		);

		$strType = jvbpd_tso()->get( 'lv_listing_single_type', 'type-grid' );
		$dynamic_options = array();
		$dynamic_options = apply_filters( 'jvbpd_' . parent::CORE_POST_TYPE . '_single_type', $strType, jvbpd_tso() );
		if( isset( $dynamic_options['newType'] ) && in_array( $dynamic_options['newType'], $arrTypes ) ) {
			$this->single_type = $dynamic_options['newType'];
		}
		$this->singlePreviewAction( parent::CORE_POST_TYPE, 'single_type' );
	}

	public function singlePreviewAction( $post_type='', $variable_name='' ) {

		$is_allowed = false;
		$arrAllowVariables = Array( 'single_type', 'resume_type' );
		$nonce_field = 'single_' . $post_type . '_action';
		$strCacheKey = sprintf( self::PREVIEW_KEY_FORMAT, $post_type, get_the_ID() );
		$strTypeName = get_transient( $strCacheKey );

		if( isset( $_POST[ $nonce_field ] ) && wp_verify_nonce( $_POST[ $nonce_field ], 'jvbpd_single_type_preview' ) ){
			$is_allowed = true;
		}

		if( 'pending' == get_post_status() && in_array( get_post_type(), array( parent::CORE_POST_TYPE ) ) ) {
			$is_allowed = true;
		}

		if( ! $is_allowed ) {
			return false;
		}

		if( isset( $_POST[ 'jvbpd_preview_single_type' ] ) && $_POST[ 'jvbpd_preview_single_type' ] != '' ) {
			$strTypeName = $_POST[ 'jvbpd_preview_single_type' ];
			set_transient( $strCacheKey, $strTypeName );
		}

		if( false === $strTypeName ) {
			return false;
		}

		if( in_array( $variable_name, $arrAllowVariables ) ) {
			$this->$variable_name = $strTypeName;
		}
	}

	public function active_hooks() {
		/* Common */

			// Mobile Menu
			add_filter( 'jvbpd_core_post_type', Array( $this, 'getSlug' ) );
			// add_action( 'jvbpd_header_container_after', array( $this, 'header_map_filter' ) );
			add_action( 'jvbpd_top_nav_menu_center', array( $this, 'header_map_filter' ) );

		/* Single */ {

			add_filter( 'jvbpd_post_title_header', Array( $this, 'hidden_sintle_title' ), 10, 2 );
			add_filter( 'jvbpd_single_post_types_array', Array( $this, 'custom_single_transparent' ) );

			// Custom CSS
			add_filter( 'jvbpd_custom_css_rows', Array( $this, 'custom_single_template_css_row' ), 20 );

			// Get Direction
			add_action( $this->core_prefix . 'single_body', Array( $this, 'append_get_direction' ) );

			// Navigation
			add_filter( 'jvbpd_detail_item_nav', Array( $this, 'custom_single_header_nav' ) );

			// Footer
			add_action( 'lava_' . parent::CORE_POST_TYPE . '_single_container_after', Array( $this, 'custom_single_dot_nav' ) );
		}

		/* Single Support */ {

			// Header
			/*
			add_filter( 'body_class' , Array( $this, 'custom_single_body_class' ) );
			add_filter( 'jvbpd_post_title_header', Array( $this, 'hidden_sintle_title' ), 10, 2 );
			add_action( 'lava_' . parent::SUPPORT_POST_TYPE . '_single_container_before', Array( $this, 'custom_single_support_header' ) );

			add_action( 'jvbpd_' . parent::SUPPORT_POST_TYPE . '_single_body', Array( $this, 'custom_single_support_body' ) );
			add_action( 'lava_' . parent::SUPPORT_POST_TYPE . '_manager_single_enqueues', Array( $this, 'custom_single_enqueues' ) );

			// Navigation
			add_filter( 'jvbpd_detail_support_nav', Array( $this, 'custom_single_support_header_nav' ) );

			// Footer
			add_action( 'lava_' . parent::SUPPORT_POST_TYPE . '_single_container_after', Array( $this, 'custom_single_dot_nav' ) );
			*/
		}

		/* Map */ {

			// Map Data
			add_action( 'lava_' . parent::CORE_POST_TYPE . '_setup_mapdata', Array( $this, 'custom_map_parameter' ), 10, 3 );

			add_action( 'lynk_map_brief_contents', Array( $this, 'map_brief_contents' ), 10, 3 );

			// Map Template Hooks
			add_action( 'lava_' . parent::CORE_POST_TYPE . '_map_wp_head', Array( $this, 'custom_map_hooks' ) );

			// Custom CSS
			add_filter( 'jvbpd_custom_css_rows', Array( $this, 'custom_map_template_css_row' ), 30 );

			// Header
			add_action( 'lava_' . parent::CORE_POST_TYPE . '_map_box_enqueue_scripts', Array( $this, 'custom_map_enqueues' ), 99 );
			add_action( 'lava_' . parent::CORE_POST_TYPE . '_map_container_before', Array( $this, 'custom_before_setup' ) );

			// Brief Window
			add_filter( 'jvbpd_brief_info_summary_items', array( $this, 'brief_summary_item' ), 10, 2 );



			// Body Class
			add_filter( 'lava_' . parent::CORE_POST_TYPE . '_map_classes', Array( $this, 'custom_map_classes' ) );


			// Map List Type
			add_filter( 'jvbpd_' . parent::CORE_POST_TYPE . '_map_list_filters', Array( $this, 'custom_mapList_filters' ) );

			// Load Templates
			add_filter( 'lava_' . parent::CORE_POST_TYPE . '_map_htmls' , Array( $this, 'custom_map_htmls' ), 10, 2 );

			add_filter( 'jvbpd_template_map_module_options', Array( $this, 'map_no_lazyload' ) );
			add_filter( 'jvbpd_template_list_module_options', Array( $this, 'map_no_lazyload' ) );

			//Filter
			$this->setFilterFields();

			add_action( 'jvbpd_map_output_class', Array( $this, 'mapOutput_class' ) );
			add_action( 'jvbpd_map_list_output_class', Array( $this, 'listOutput_class' ) );

			// Option
			add_action( 'jvbpd_core_map_template_layout_setting_after', Array( $this, 'layout_setting' ), 10, 2 );
		}

		/* Archive */
		{
			/*
			add_filter( 'jvbpd_template_list_module', Array( $this, 'archive_map_list_module' ), 10, 2 );
			add_filter( 'jvbpd_template_list_module_loop', Array( $this, 'archive_map_list_module_loop' ), 10, 3 );
			add_filter( 'jvbpd_template_map_module', Array( $this, 'archive_map_module' ), 10, 2 );
			add_filter( 'jvbpd_template_map_module_loop', Array( $this, 'archive_map_module_loop' ), 10, 3 ); */

			add_filter( 'lava_' . parent::CORE_POST_TYPE . '_get_template' , Array( $this, 'custom_archive_page' ), 10, 3 );
			add_filter( 'jvbpd_map_class', Array( $this, 'custom_map_class' ), 30, 2 );
			add_filter( 'jvbpd_' . parent::CORE_POST_TYPE . '_map_list_content_column_class', Array( $this, 'custom_list_content_column' ), 10, 3 );
			add_action( 'jvbpd_' . parent::CORE_POST_TYPE . '_map_list_container_before', Array( $this, 'map_list_container_before' ), 15 );
			add_action( 'jvbpd_' . parent::CORE_POST_TYPE . '_map_list_container_after', Array( $this, '_map_list_container_after' ) );
		}

		/* Widget */{
			add_filter( 'jvbpd_recent_posts_widget_excerpt', Array( $this, 'core_recentPostsWidget' ), 10, 4 );
			add_filter( 'jvbpd_recent_posts_widget_describe_type_options', Array( $this, 'core_recentPostsWidgetOption' ), 10, 1 );
		}
	}

	public function load_map_type_switcher(){
		$this->load_template( 'part-map-type-switcher' );
	}

	public function load_map_inline_filter(){
		$this->load_template( 'part-map-inline-filter' );
	}




	public function custom_load_map() {
		$strFileName = parent::$instance->template_path .'/template-map-container.php';
		if( ! file_exists( $strFileName ) ) {
			esc_html_e( "Not found template type", 'jvfrmtd' );
			return;
		}
		require_once( $strFileName );
	}

	public function custom_map_scripts() {
		$strFileName		= Array();
		$strFileName[]		= parent::$instance->template_path;
		$strFileName[]		= 'scripts-map-multipleBox.php';
		$strFileName		= @implode( '/', $strFileName );

		if( !file_exists( $strFileName ) ){
			wp_die( new WP_Error( 'not-found-map-script', __( "Not found script : ", 'jvfrmtd' ) . $strFileName ) );
		}

		require_once( $strFileName );
	}

	public function single_hooks() {
		$this->setCoreSingleType();

		add_filter( 'body_class' , Array( $this, 'custom_single_body_class' ) );
		add_action( 'lava_' . parent::CORE_POST_TYPE . '_single_container_before', Array( $this, 'custom_single_header' ) );
		add_action( 'jvbpd_' . parent::CORE_POST_TYPE . '_single_body', Array( $this, 'custom_single_body' ) );
		add_action( 'lava_' . parent::CORE_POST_TYPE . '_manager_single_enqueues', Array( $this, 'custom_single_enqueues' ) );
		if( is_single() ) {
			add_action('wp_head',  Array( $this, 'jv_fb_thumbnail'));
		}

		add_filter( 'jvbpd_' . parent::CORE_POST_TYPE . '_single_tab_menus', Array( $this, 'single_tab_menus' ) );

		switch ($this->single_type) {
		case 'type-a':
			add_action( 'jvbpd_' . parent::CORE_POST_TYPE . '_single_description_before', Array( $this, 'append_vendor_produce' ) );
			add_action( $this->core_prefix . 'single_booking', Array( $this, 'append_booking_form' ), 9 );
			break;
		case 'type-b':
			add_action( 'jvbpd_' . parent::CORE_POST_TYPE . '_single_description_before', Array( $this, 'append_vendor_produce' ) );
		    add_action( $this->core_prefix . 'single_booking', Array( $this, 'append_booking_form' ), 9 );
			break;
		case 'type-c':
			add_action( 'jvbpd_' . parent::CORE_POST_TYPE . '_single_description_before', Array( $this, 'append_vendor_produce' ) );
			break;
		case 'type-half':
			add_action( 'jvbpd_' . parent::CORE_POST_TYPE . '_single_description_before', Array( $this, 'append_vendor_produce' ) );
			add_action( $this->core_prefix . 'single_booking', Array( $this, 'append_booking_form' ), 9 );
			break;
		case 'type-grid':
			add_action( 'jvbpd_' . parent::CORE_POST_TYPE . '_single_author_after', Array( $this, 'append_vendor_produce' ) );
			add_action( $this->core_prefix . 'single_booking', Array( $this, 'append_booking_form' ), 9 );
			break;
		case 'type-top-tab':
			add_action( 'jvbpd_' . parent::CORE_POST_TYPE . '_single_vendor', Array( $this, 'append_vendor_produce' ) );
			add_action( $this->core_prefix . 'single_booking', Array( $this, 'append_booking_form' ), 9 );
			break;
		case 'type-left-tab':
			add_action( 'jvbpd_' . parent::CORE_POST_TYPE . '_single_vendor', Array( $this, 'append_vendor_produce' ) );
			add_action( $this->core_prefix . 'single_booking', Array( $this, 'append_booking_form' ), 9 );
			break;
		}
		add_action( 'wp_footer', array( $this, 'single_control_buttons' ) );
	}

	public function jv_fb_thumbnail(){
		global $post, $jvbpd_tso;
		if(get_the_post_thumbnail($post->ID, 'thumbnail')) {
			$image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
		} else {
			$image = $jvbpd_tso->get('no_image', JVBPD_IMG_DIR.'/no-image.png');
		}
		echo '<meta property="og:image" content="'.$image.'"/>';
	}

	public function load_template( $template_name, $extension='.php' , $params=Array(), $_once=true ) {

		if( !empty( $params ) ) {
			extract( $params );
		}

		$strFileName = jvlynkCore()->template_path . '/' . $template_name . $extension;
		$strFileName = apply_filters( 'jvbpd_core_load_template', $strFileName, $template_name );

		if( file_exists( $strFileName ) ) {
			if( $_once ) {
				require_once $strFileName;
			}else{
				require $strFileName;
			}
			return true;
		}
		return false;
	}

	public function custom_single_body_class( $body_classes=Array() ) {

		$arrSinglePostType = Array( parent::CORE_POST_TYPE, parent::SUPPORT_POST_TYPE );
		$body_classes[] = $this->single_type;
		$body_classes[] = 'extend-meta-block';

		if( in_array( get_post_type(), $arrSinglePostType ) )
			$body_classes[]	= 'no-sticky';

		return $body_classes;
	}

	public function header_map_filter() {
		$this->load_template( 'part-header-map-filter' );
	}

	public function hidden_sintle_title( $post_title='', $post=null ) {
		if( is_null( $post ) || get_post_type( $post ) === parent::CORE_POST_TYPE )
			$post_title = null;

		return $post_title;
	}

	public function custom_single_transparent( $post_types=Array() ){
		$post_types[] = parent::CORE_POST_TYPE;
		return $post_types;
	}

	public function custom_single_enqueues(){
		wp_enqueue_style( jvlynkCore()->var_instance->getHandleName( 'single.css' ) );
		wp_enqueue_script( 'jquery-sticky' );
		wp_enqueue_script( 'zeroclipboard' );
		wp_enqueue_script( 'lightgallery-all' );
		wp_enqueue_script( 'swiper' );

		wp_localize_script(
			jvlynkCore()->var_instance->getHandleName( 'jvbpd-listing-single' ),
			'jvbpd_custom_post_param',
			Array(
				'widget_sticky' => jvbpd_tso()->get( jvlynkCore()->var_instance->slug . '_single_sticky_widget' ),
				'map_type' => jvbpd_tso()->get( jvlynkCore()->var_instance->slug . '_map_width_type' ),
				'single_type' => $this->single_type,
				'map_style' => stripslashes( htmlspecialchars_decode( jvbpd_tso()->get( 'map_style_json' ) ) ),
			)
		);

		wp_enqueue_script( jvlynkCore()->var_instance->getHandleName( 'jvbpd-listing-single' ) );
	}

	public function custom_single_header() {
		$this->load_template( 'part-single-header-' . $this->single_type );
		$this->load_template( 'addon-header-spyscroll-nav' );
	}

	public function custom_single_body() {
		$this->load_template( 'template-single-' . $this->single_type );
	}

	public function custom_single_support_header() {
		$this->load_template( 'part-single-header-' . $this->support_type );
	}

	public function custom_single_support_body() {
		$this->load_template( 'template-single-' . $this->support_type );
	}

	public function single_tab_menus( $menus=Array() ) {

		if( function_exists( 'lava_directory_booking' ) && get_post_meta( get_the_ID(), '_booking', true ) ) {
			$menus[ 'booking' ] = Array(
				'label' => esc_html__( "Booking", 'jvfrmtd' ),
				'icon' => "jvd-icon-calendar"
			);
		}
		$menus[ 'others' ] = Array(
			'label' => esc_html__( "Others", 'jvfrmtd' ),
			'icon' => "jvd-icon-website_1"
		);
		return $menus;
	}


	public function append_vendor_produce() {
		if( !function_exists( 'lava_directory_vendor' ) )
			return;

		if( ! $intVendorID = intVal( lava_directory_vendor()->core->getVendorID() ) )
			return;

		$this->load_template(
			'part-single-vendor-products',
			'.php',
			Array(
				'vendor_products' => lava_directory_vendor()->core->getProducts(
					Array(
						'vendor'	=> $intVendorID,
						'exclude_booking' => true,
					)
				)
			)
		);
	}

	public function append_booking_form() {

		if( !function_exists( 'lava_directory_booking' ) || !function_exists( 'wc_get_template') || !class_exists( 'WC_Booking_Form' ) )
			return;

		$bookingProductID = lava_directory_booking()->core->getProductID();
		$GLOBALS[ 'product' ] = $bookingProduct = get_product( $bookingProductID );

		if( !$bookingProduct )
			return;

		if( $bookingProduct->product_type != 'booking' )
			return;

		$objForm = new WC_Booking_Form( $bookingProduct );

		$this->load_template(
			'part-single-booking-form',
			'.php',
			Array(
				'jvbpd_booking_form' => $objForm
			)
		);
	}

	public function setSingleType( $post_id=0, $post ) {

		if( ! in_array( $post->post_type, Array( parent::CORE_POST_TYPE ) ) || $post->post_status != 'publish' ) {
			return false;
		}

		if( ! function_exists( 'lync_single' ) ) {
			return false;
		}

		$strKeyName = jvbpd_single()->admin->fieldName;
		$strCacheKey = sprintf( self::PREVIEW_KEY_FORMAT, $post->post_type, $post_id );
		$strTypeName = get_transient( $strCacheKey );

		if( 0 < intVal( $post_id ) && false !== $strTypeName ) {
			$arrOldValues = get_post_meta( $post_id, $strKeyName, true );
			if( is_array( $arrOldValues ) ) {
				$arrOldValues[ 'singleType' ] = $strTypeName;
			}else{
				$arrOldValues = Array( 'singleType' => $strTypeName );
			}
			update_post_meta( $post_id, $strKeyName, $arrOldValues );
			delete_transient( $strCacheKey );
		}
	}

	public function single_template( $template ) {
		$post = get_queried_object();

		if( $post instanceof WP_Post ) {
			if( $post->post_type == 'lv_listing' ) {
				$fileName = jvlynkCore()->template_path . '/single-lv_listing.php';
				if( file_exists( $fileName ) ) {
					$template = $fileName;
				}
			}
		}
		return $template;
	}

	public function custom_single_template_css_row( $rows=Array() ){
		$strPrefix = 'html body.single.single-' . jvlynkCore()->var_instance->slug . ' ';

		$rows[] = $strPrefix . 'header#header-one-line nav.javo-main-navbar';
		$rows[] = '{ top:auto; position:relative; left:auto; right:auto; }';

		return $rows;
	}

	public function custom_single_support_template_css_row( $rows=Array() ){
		$strPrefix = 'html body.single.single-' . parent::SUPPORT_POST_TYPE . ' ';

		$rows[] = $strPrefix . 'header#header-one-line nav.javo-main-navbar';
		$rows[] = '{ top:auto; position:relative; left:auto; right:auto; }';

		return $rows;
	}

	public function append_get_direction(){
		if( !function_exists( 'lava_directory_direction'  ) )
			return;

		$this->load_template(
			'part-single-get-direction',
			'.php',
			Array(
				'objGetDirection' => lava_directory_direction()->template
			)
		);
	}

	public function custom_single_header_nav( $args=Array() ) {

		$arrAllowPostTypes = apply_filters( 'jvbpd_single_post_types_array', Array( 'lv_listing' ) );
		$append_args = Array();
		/*$append_args[ 'javo-item-condition-section'	 ]	= Array(
			'label' => esc_html__( "Detail", 'jvfrmtd' )
			, 'class' => 'glyphicon glyphicon-tasks'
			, 'type' => $arrAllowPostTypes
		); */
		$append_args[ 'javo-item-describe-section' ]	= Array(
			'label' => esc_html__( "Description", 'jvfrmtd' )
			, 'class' => 'glyphicon glyphicon-align-left'
			, 'type' => $arrAllowPostTypes
		);
		$append_args[ 'javo-item-amenities-section'	 ]	= Array(
			'label' => esc_html__( "Amenities", 'jvfrmtd' )
			, 'class' => 'glyphicon glyphicon-ok-circle'
			, 'type' => $arrAllowPostTypes
		);
		if( class_exists( 'Lava_Directory_Review' ) ) :
			$append_args[ 'javo-item-review-section' ]	= Array(
				'label' => esc_html__( "Review", 'jvfrmtd' )
				, 'class' => 'glyphicon glyphicon-comment'
				, 'type' => $arrAllowPostTypes
			);
		endif;

		return wp_parse_args( $append_args, $args );
	}

	public function custom_single_support_header_nav( $args=Array() ) {

		$arrAllowPostTypes = Array( parent::SUPPORT_POST_TYPE );
		$append_args = Array();
		$append_args[ 'lynk-support-last-answer'	 ]	= Array(
			'label' => esc_html__( "Last Answer", 'jvfrmtd' )
			, 'class' => 'glyphicon glyphicon-tasks'
			, 'type' => $arrAllowPostTypes
		);
		$append_args[ 'lynk-support-update-ticket' ] = Array(
				'label' => esc_html__( "Update Ticket", 'jvfrmtd' )
				, 'class' => 'glyphicon glyphicon-comment'
				, 'type' => $arrAllowPostTypes
		);
		$append_args[ 'lynk-support-policy' ]	= Array(
			'label' => esc_html__( "Support Policy", 'jvfrmtd' )
			, 'class' => 'glyphicon glyphicon-ok-circle'
			, 'type' => $arrAllowPostTypes
		);
		$append_args[ 'lynk-support-hour' ] = Array(
			'label' => esc_html__( "Support Hours", 'jvfrmtd' )
			, 'class' => 'glyphicon glyphicon-align-left'
			, 'type' => $arrAllowPostTypes
		);
		$append_args[ 'lynk-support-watch' ] = Array(
			'label' => esc_html__( "Save This Ticket", 'jvfrmtd' )
			, 'class' => 'glyphicon glyphicon-map-marker'
			, 'type' => $arrAllowPostTypes
		);

		return wp_parse_args( $append_args, $args );
	}

	public function custom_single_dot_nav() {
		$this->load_template( 'part-single-dot-nav' );
	}

	public function single_control_buttons() {
		$post = get_post();
		if( ! in_array( get_post_type( $post ), Array( parent::CORE_POST_TYPE ) ) || get_post_status( $post ) != 'pending' ) {
			return false;
		}
		$this->load_template( 'part-single-layer-preview', '.php', array( 'post' => $post ) );
	}

	public function woo_func() {
		add_action( 'jvbpd_sidebar_id', Array( $this, 'woo_sidebar' ), 10, 2 );
		add_filter( 'jvbpd_sidebar_position', array( $this, 'woo_sidebar_position' ), 15, 2 );
	}

	public function loadLess() {
		add_filter( 'jvbpd_enqueue_less_array', array( $this, 'core_less' ) );
		add_filter( 'jvbpd_enqueue_css_array', array( $this, 'core_csses' ) );
	}

	public function core_less( $lesses=Array() ) {
		$lesses[ 'map-style-less' ] = Array(
			'dir' => jvlynkCore()->assets_url . 'less',
			'file' => 'maps.less',
		);
		$lesses[ 'single-style-less' ] = Array(
			'dir' => jvlynkCore()->assets_url . 'less',
			'file' => 'single.less',
		);
		$lesses[ 'theme-compatibility-less' ] = Array(
			'dir' => jvlynkCore()->assets_url . 'less',
			'file' => 'theme-compatibility.less',
		);
		$lesses[ 'buddypress-less' ] = Array(
			'dir' => jvlynkCore()->assets_url . 'less',
			'file' => 'buddypress.less',
		);
		return $lesses;
	}

	public function core_csses( $csses=Array() ) {
		$csses[ 'map-style-css' ] = Array(
			'dir' => jvlynkCore()->assets_url . 'css',
			'file' => 'maps.css',
		);
		$csses[ 'single-style-css' ] = Array(
			'dir' => jvlynkCore()->assets_url . 'css',
			'file' => 'single.css',
		);
		$csses[ 'theme-compatibility-css' ] = Array(
			'dir' => jvlynkCore()->assets_url . 'css',
			'file' => 'theme-compatibility.css',
		);
		$csses[ 'buddypress-css' ] = Array(
			'dir' => jvlynkCore()->assets_url . 'css',
			'file' => 'buddypress.css',
		);
		return $csses;
	}

	public function custom_map_parameter( $obj, $get=false, $post=false ) {
		$_instance = get_queried_object();
		$term_id = 0;

		if( $_instance instanceof WP_Term ) {
			$term_id = intVal( $_instance->term_id );
		}

		if( !$obj instanceof WP_Post ) {
			return;
		}

		$obj->requests = Array();

		if( ! method_exists( $get, 'get' ) || ! method_exists( $post, 'get' ) ) {
			return;
		}

		$taxonomies = apply_filters( 'jvbpd_map_requests', array( 'category', 'geolocation' ), $obj );
		if( is_array( $taxonomies ) ) {
			foreach( $taxonomies as $taxonomy ) {
				$obj->requests[ $taxonomy ] = $get->get( $taxonomy, $post->get( $taxonomy, $term_id ) );
			}
		}
		add_filter( 'body_class', array( $this, 'sidebar_disable_class' ), 999 );
		add_filter( 'jvbpd_post_title_header', '__return_false' );
		add_filter( 'jvbpd_left_sidebar_display', '__return_false' );
		add_filter( 'jvbpd_member_sidebar_display', '__return_false' );
		add_action( 'wp_footer', array( $this, 'map_template_append_right_sidebar' ) );
	}

	public function sidebar_disable_class( $classes=array() ) {
		$classes[] = 'sidebar-disabled';
		return array_diff( $classes, array( 'member-sidebar-active' ) );
	}

	public function map_template_append_right_sidebar() {
		get_template_part('library/header/right', 'sidebar');
	}

	public function map_brief_contents( $html=Array(), $post ) {
		ob_start();
		$this->load_template( 'template-brief-contents', '.php', array( 'jvbpd_post' => $post ) );
		$html = Array( ob_get_clean() );
		return $html;
	}

	public function custom_map_hooks() {

		$options = (Array) get_post_meta( get_the_ID(), 'jvbpd_map_page_opt', true );
		$strOptionName = 'mobile_type';

		if(
			is_array( $options ) &&
			!empty( $options[ $strOptionName ] )  &&
			$options[ $strOptionName ] == 'ajax-top'
		){
			add_action( 'jvbpd_header_brand_right_after', Array( $this, 'addition_inner_switcher' ), 15 );
		}

	}

	public function custom_map_template_css_row( $rows ){
		$strPrefix		= 'html body.page-template.page-template-lava_' . jvlynkCore()->var_instance->slug . '_map' . ' ';
		$strPrimary		= jvbpd_tso()->get( 'total_button_color', false );
		$strPrimary_text = jvbpd_tso()->get( 'primary_font_color', false );
		$strPrimary_border = 'none';
		if(jvbpd_tso()->get('total_button_border_use', false) == 'use' && jvbpd_tso()->get( 'total_button_border_color')!='' ){
			$strPrimary_border = '1px solid '.jvbpd_tso()->get( 'total_button_border_color', false );
		}
		$strPrimaryRGB	= apply_filters( 'jvbpd_rgb', substr( $strPrimary, 1) );

		$rows[] = "body{ background-color:#f00; }";

		if( $strPrimary ){
			$rows[] = $strPrefix . ".javo-shortcode .module .meta-category:not(.no-background),";
			$rows[] = $strPrefix . ".javo-shortcode .module .media-left .meta-category:not(.no-background)";
			// $rows[] = ".jvbpd-header-map-filter-wrap";
			/** ----------------------------  */
			$rows[] = "{ background-color:{$strPrimary}; color:{$strPrimary_text}; border:{$strPrimary_border}; }";

			$rows[] = $strPrefix . ".javo-shortcode .module.javo-module12 .thumb-wrap:hover .javo-thb:after";
			/** ----------------------------  */
			$rows[] = "{ background-color:rgba({$strPrimaryRGB['r']}, {$strPrimaryRGB['g']}, {$strPrimaryRGB['b']}, .92); }";
		}

		return apply_filters( 'jvbpd_' . parent::CORE_POST_TYPE . '_custom_map_css_rows', $rows, $strPrefix );
	}

	public function custom_map_enqueues() {
		global $post;

		$is_empty_post = false;

		wp_enqueue_script( 'jquery-nouislider' );
		wp_enqueue_script( 'jquery-typehead' );
		wp_enqueue_script( 'selectize' );
		wp_enqueue_script( 'jquery-sticky' );
		wp_enqueue_script( 'jQuery-chosen-autocomplete' );

		if( !is_object( $post ) ){
			$is_empty_post = true;
			$post = new stdClass();
			$post->lava_type = $this->slug;
			$post->ID = 0;
		}

		$objOptions = new jvbpd_Array( (Array)get_post_meta( $post->ID, 'jvbpd_map_page_opt', true ) );

		wp_localize_script(
			jvlynkCore()->var_instance->getHandleName( 'map-template' ),
			'jvbpd_core_map_param',
			apply_filters(
				'jvbpd_' . parent::CORE_POST_TYPE . '_map_params',
				Array(
					'ajaxurl' => admin_url( 'admin-ajax.php' ),
					'cross_domain' => $this->is_cross_domain,
					'json_hook' => $this->strGetJsonHook,
					'json_file' => $this->json_file,
					'json_security' => wp_create_nonce( $this->strGetJsonHook ),
					'template_id' => $post->ID,
					'selctize_terms' => Array( 'listing_category', 'listing_location' ),
					'strLocationAccessFail' => esc_html__( "Your position access failed.", 'jvfrmtd' ),
					'amenities_filter' => $objOptions->get( 'amenities_filter' ),
					'allow_wheel' => jvbpd_tso()->get( 'map_allow_mousewheel', 'a' ),
					'map_marker' => $objOptions->get( 'map_marker', jvbpd_tso()->get( 'map_marker' ) ),
					'strings' => Array(
						'multiple_cluster' => esc_html__( "This place contains multiple places. please select one.", 'jvfrmtd' )
					),
				),
				jvbpd_tso(), $objOptions
			)
		);

		if( $is_empty_post )
			$post=  null;

		wp_enqueue_script( jvlynkCore()->var_instance->getHandleName( 'map-template' ) );
	}

	public function custom_before_setup( $post ) {
		$is_core_map_actived = class_exists( 'Lynk_Core_Map' );
		if( get_post_meta( get_post()->ID, '_map_filter_position', true ) == 'map-layout-search-top' && $is_core_map_actived )
			add_action( 'jvbpd_' . parent::CORE_POST_TYPE . '_map_switcher_before', Array( $this, 'custom_map_listing_filter' ) );
		else
			add_action( 'jvbpd_' . parent::CORE_POST_TYPE . '_map_lists_before', Array( $this, 'custom_map_listing_filter' ) );
	}

	public function brief_summary_item( $items=array(), $post_id=0 ) {

		if( ! function_exists( 'javo_moreTax' ) ) {
			return;
		}
		$arrTaxonomies = javo_moreTax()->admin->getMoreTaxonomies();
		$arrTaxonomiesNames = Array();

		if( !empty( $arrTaxonomies ) && is_array( $arrTaxonomies ) ) {
			foreach( $arrTaxonomies as $arrTax ) {
				if( !empty( $arrTax[ 'name' ] ) ) {
					$arrTaxonomiesNames[] = $arrTax[ 'name' ];
				}
			}
		}

		foreach( $arrTaxonomiesNames as $taxName ) {
			$arrTerms = wp_get_object_terms( $post_id, $taxName, array( 'fields' => 'names' ) );
			$items[] = Array(
				'label' => get_taxonomy( $taxName )->label,
				'value' => join( ', ', $arrTerms )
			);
		}

		return $items;
	}

	public function addition_inner_switcher(){
		$this->load_template( 'part-map-filter-inner-switcher', '.php', Array( 'post' => $GLOBALS[ 'post' ] ), false );
	}

	public function custom_map_classes( $classes=Array() ){

		$classes[] = 'no-sticky';
		$classes[] = 'no-smoth-scroll';
		// $classes[] = 'mobile-ajax-top';
		$classes[] = 'mobile-active';

		$options = (Array) get_post_meta( get_the_ID(), 'jvbpd_map_page_opt', true );
		$strOptionName = 'mobile_type';

		if( is_array( $options ) && !empty( $options[ $strOptionName ] ) )
			$classes[] = 'mobile-' . $options[ $strOptionName ];

		return $classes;
	}

	public function custom_mapList_filters( $filters=Array() ){

		global $post;

		return Array(
			wp_parse_args(
				Array(
					'geo-location'	=>
						Array(
							'label'		=> esc_html__( "Location", 'jvfrmtd' )
							, 'inner'		=> Array(
								Array(
									'ID'					=> 'javo-map-box-location-trigger'
									, 'type'				=> 'location'
									, 'class'				=> 'form-control javo-location-search'
									, 'value'				=> $post->lynk_current_rad
									, 'placeholder'	=> esc_html__( "Location", 'jvfrmtd' )
								)
								, Array( 'type'		=> 'separator' )
								, Array(
									'type'				=> 'division'
									, 'class'				=> 'javo-geoloc-slider-trigger'
								)
							)
						)
					, 'filter-keyword'				=>
						Array(
							'label'						=> esc_html__( "Keyword", 'jvfrmtd' )
							, 'inner'						=> Array(
								Array(
									'ID'					=> 'jv-map-listing-keyword-filter'
									, 'type'				=> 'text'
									, 'class'				=> 'form-control jv-keyword-trigger'
									, 'value'				=> $post->lava_current_key
									, 'placeholder'	=> esc_html__( "Keyword", 'jvfrmtd' )
								)
							)
						)
					, 'filter-categories'				=>
						Array(
							'label'							=> esc_html__( "Types", 'jvfrmtd' )
							, 'inner'						=> Array(
								Array(
									'type'					=> 'select'
									, 'class'				=> 'form-control'
									, 'taxonomy'		=> 'listing_category'
									, 'value'				=> $post->req_listing_category
									, 'placeholder'	=> esc_html__( "All Categories", 'jvfrmtd' )
								)
								, Array(
									'type'				=> 'select'
									, 'class'				=> 'form-control'
									, 'taxonomy'		=> 'listing_location'
									, 'value'				=> $post->req_listing_location
									, 'placeholder'	=> esc_html__( "All Locations", 'jvfrmtd' )
								)
							)
						)
					, 'filter-amenities'			=> Array(
						'label'					=> esc_html__( "Amenities", 'jvfrmtd' ),
						'inner'				=> Array(
							Array(
								'type'		=> 'division',
								'class'		=> 'amenities-filter-area list-type',
							),
						)
					)
				)
			), $filters
		);
	}

	public function listing_mobile_filter( $post ) {
		$this->load_template( 'html-map-mobile-listing-menu', '.php', Array( 'post' => $post )  );
	}

	public function custom_map_htmls( $args, $plug_dir ) {
		$tmpDir		= parent::$instance->template_path . '/';
		return Array(
			'javo-map-loading-template' => $tmpDir . 'html-map-loading.php',
			'javo-map-box-panel-content' => $tmpDir . 'html-map-grid-template.php',
			'javo-map-box-infobx-content' => $tmpDir . 'html-map-popup-contents.php',
			'javo-list-box-content' => $tmpDir . 'html-list-box-contents.php',
			'javo-map-inner-control-template' => $tmpDir . 'html-map-inner-controls.php',
			'lynk-map-inner-panel' => $tmpDir . 'html-map-inner-panel.php',
			'jvbpd-map-mobile-buttons' => $tmpDir . 'html-map-mobile-button.php',
			'jvbpd-map-distance-bar' => $tmpDir . 'html-map-distance-bar.php',
		);
	}

	public function map_no_lazyload( $args=Array() ){ return wp_parse_args( Array( 'no_lazy' => true ), $args ); }

	public function mapOutput_class( $classes=Array() ){

		$classes[] = 'module-hover-zoom-in';
		return $classes;

	}

	public function listOutput_class( $classes=Array() ){

		$classes[] = 'module-hover-zoom-in';
		return $classes;
	}

	public function layout_setting( $post, $objOption ) {

		$strOptionName = 'mobile_type';
		$strOptionBuffer = '';
		foreach(
			Array(
				'' => __( "Default", 'jvfrmtd' ),
				'ajax-top' => __( "Ajax Top", 'jvfrmtd' ),
			) as $value => $label
		) $strOptionBuffer .= sprintf(
			"<option value=\"{$value}\"%s>{$label}</option>",
			selected( $value == $objOption->get( $strOptionName, '' ), true, false )
		);

		printf(
			'<tr><th> <label>%1$s</label> </th><td>
				<select name="lynk_map_opts[%2$s]">%3$s</select>
				<div><small>%4$s</small></div>
			</td></tr>',
			__( "Mobile Map Search Type", 'jvfrmtd' ),
			$strOptionName,
			$strOptionBuffer,
			__( 'Note : if you choose ajax top option, "Initial display - MAP or LIST first" option will be disabled on mobile version ( lower than width 768px)', 'jvfrmtd' )
		);

	}

	public function setFilterFields() {
		$orderFields		= Array(
			/*
			Array(
				'position'	=> 'outer',
				'callback'	=> 'fieldAddress'
			),
			Array(
				'position'	=> 'outer',
				'callback'	=> 'fieldCategory'
			),
			Array(
				'position'	=> 'outer',
				'callback'	=> 'fieldKeyword'
			),*/
			Array(
				'position'	=> 'outer',
				'callback'	=> 'fieldMenu'
			),

			/*
			Array(
				'position'	=> 'outer',
				'callback'	=> 'fieldOrder'
			), */

			/*
			Array(
				'position'	=> 'inner',
				'callback'	=> 'fieldLocation'
			), */

			Array(
				'position'	=> 'outer',
				'callback'	=> 'fieldTax'
			),

			/*
			Array(
				'position'	=> 'inner',
				'callback'	=> 'fieldMeta'
			), */
		);
		$arrFilters = apply_filters( 'jvbpd_' . parent::CORE_POST_TYPE . '_map_filter_orders', $orderFields );

		if( !empty( $arrFilters ) ) : foreach( $arrFilters as $index => $filter ) {
			if( is_array( $filter[ 'callback' ] ) ) {
				add_action( 'jvbpd_map_template_filter_' . $filter[ 'position' ], $filter[ 'callback' ], intVal( $index + 10 ) );
			} elseif( method_exists( $this, $filter[ 'callback' ] ) ) {
				add_action( 'jvbpd_map_template_filter_' . $filter[ 'position' ], Array( $this, $filter[ 'callback' ] ), intVal( $index + 10 ) );
			}
		} endif;
	}

	public function fieldAddress(){
		$this->load_template( 'part-map-filter-address', '.php', Array( 'post' => $GLOBALS[ 'post' ] ), false );
	}

	public function fieldKeyword(){
		$this->load_template( 'part-map-filter-keyword', '.php', Array( 'post' => $GLOBALS[ 'post' ] ), false );
	}

	public function fieldOrder() {
		$this->load_template( 'part-map-filter-order', '.php', Array( 'post' => $GLOBALS[ 'post' ] ), false );
	}

	public function fieldLocation(){
		$this->load_template( 'part-map-filter-location', '.php', Array( 'post' => $GLOBALS[ 'post' ] ), false  );
	}

	public function fieldCategory(){
		$this->load_template( 'part-map-filter-category', '.php', Array( 'post' => $GLOBALS[ 'post' ] ), false  );
	}

	public function fieldMeta(){
		$this->load_template( 'part-map-filter-meta', '.php', Array( 'post' => $GLOBALS[ 'post' ] ), false  );
	}

	public function fieldTax(){
		$this->load_template( 'part-map-filter-taxonomy', '.php', Array( 'post' => $GLOBALS[ 'post' ] ), false  );
	}

	public function fieldMenu(){
		$this->load_template( 'part-map-filter-menu', '.php', Array( 'post' => $GLOBALS[ 'post' ] ), false  );
	}


	public function custom_archive_page( $template, $query=false, $obj=false ) {
		$taxonomy = empty( $query->queried_object->taxonomy ) ?
			Array() : get_taxonomy( $query->queried_object->taxonomy )->object_type;

		if(
			!empty( $query->queried_object->taxonomy ) &&
			!in_Array( $query->queried_object->taxonomy,
				Array( 'listing_keyword' )
			)
		) if( !empty( $query ) && !empty( $obj ) )
			if( $query->is_archive && in_array( parent::CORE_POST_TYPE, $taxonomy ) ) {
				$this->is_archive = true;
				$obj->get_map_template();
				$template = $this->initMapTemplate();
			}

		return $template;
	}

	public function custom_map_class( $classes ) {

		$classes[] = 'mobile-active';



		if( $this->is_archive ) {
			// hide-switcher
			$classes	= wp_parse_args(
				Array( 'hide-listing-filter' )
				, $classes
			);
		}
		return $classes;
	}

	public function custom_list_content_column( $class_name ) {
		if( $this->is_archive )
			$class_name	= 'col-sm-12';
		return $class_name;
	}

	public function archive_map_list_module( $module_name, $post_id ) {
		if( ! $post_id )
			$module_name		= 'module12';
		return $module_name;
	}

	public function archive_map_list_module_loop( $template, $class_name, $post_id ) {
		if( ! $post_id )
			$template				= "<div class=\"col-md-4\">%s</div>";
		return$template;
	}

	public function archive_map_module( $module_name, $post_id ) {
		if( ! $post_id )
			$module_name		= 'module12';
		return $module_name;
	}

	public function archive_map_module_loop( $template, $class_name, $post_id ) {
		if( ! $post_id )
			$template				= "<div class=\"col-md-6\">%s</div>";
		return$template;
	}

	public function map_list_container_before( $post ) {
		if( $this->is_archive ){
			$this->load_template( 'part-archive-container-header' );
		}
	}

	public function _map_list_container_after( $post ) {
		if( $this->is_archive ){
			$this->load_template( 'part-archive-container-footer' );
		}
	}

	public function custom_map_listing_filter( ) {
		global $post;

		$strFileName = parent::$instance->template_path . '/html-map-mainFilter.php';
		if( !file_exists( $strFileName ) ){
			wp_die( new WP_Error( 'not-found-map-filter', __( "Not found filter : ", 'jvfrmtd' ) . $strFileName ) );
		}

		require_once $strFileName;
	}

	public function core_recentPostsWidget( $excerpt='', $length=0, $post=false, $args=null ){

		$isMoreMeta = is_array( $args ) &&
			!empty( $args[ 'describe_type' ] ) &&
			$args[ 'describe_type' ] == 'rating_category';

		if(
			$isMoreMeta &&
			class_exists( 'Lynk_Bp_Module' ) &&
			is_object( $post ) &&
			$post->post_type == jvlynkCore()->var_instance->slug
		) {

			$objModule = new Lynk_Bp_Module( $post );
			$excerpt = join( false, Array(
				'<div class="javo-shortcode">',
					'<div class="module">',
						sprintf( jvlynkCore()->var_instance->shortcode->contents_with_raty_star( '', $objModule ) ),
						'<div class="meta-moreinfo">',
							sprintf(
								'<span class="meta-category">%s</span>',
								$objModule->c( 'listing_category', esc_html__( "No Category", 'jvfrmtd'	 ) )
							),
							' / ',
							sprintf(
								'<span class="meta-location">%s</span>',
								$objModule->c( 'listing_location', esc_html__( "No Location", 'jvfrmtd'	 ) )
							),
						'</div>',
					'</div>',
				'</div>',
			) );
		}
		return $excerpt;
	}

	public function core_recentPostsWidgetOption( $options=Array() ){
		if( class_exists( 'Lava_Directory_Review' ) )
			$options[ 'rating_category' ] = esc_html__( "Rating & Category ( only 'listing' )", 'jvfrmtd' );

		return $options;
	}

	public function woo_sidebar( $sidebar_id='', $post ) {
		if( function_exists( 'is_woocommerce' ) && is_woocommerce() ) {
			$sidebar_id = 'woo-sidebar';
		}
		return $sidebar_id;

	}

	public function woo_sidebar_position( $position='', $post_id=0 ) {
		if( function_exists( 'is_woocommerce' ) && is_woocommerce() ) {
			if( is_archive() ) {
				$position = jvbpd_tso()->get( 'woo_archive_sidebar', 'right' );
			}elseif( is_singular( 'product' ) ) {
				$position = jvbpd_tso()->get( 'woo_single_sidebar', 'right' );
			}
		}
		return $position;
	}

	public function renderHeaderSearchMenu( $args=null ) {


		/**
		<ul class="hidden-sm hidden-md hidden-lg">
			<li class="menu-item jvbpd-menu jvbpd-search1-opener">
				<a class="jvbpd-btn-search1-opener ">
					<i class="fa fa-search"></i>
				</a>
				<a class="jvbpd-btn-map-mobile-switcher jvbpd-map-mobile-switch">
					<i class="fa fa-map-marker"></i>
				</a>
			</li>
		</ul>
		*/

		$item_buffer = $menu_classes = Array();
		$menu_classes[] = 'main-menu-item';
		$menu_classes[] = 'menu-item-depth-0';
		$menu_classes[] = 'jvbpd-menu';
		$menu_classes[] = 'jvbpd-search1-opener';
		$menu_classes[] = 'menu-item';
		$menu_classes[] = 'menu-item-type-custom';
		$menu_classes[] = 'menu-item-object-custom';
		$menu_classes[] = 'hidden-sm';
		$menu_classes[] = 'hidden-md';
		$menu_classes[] = 'hidden-lg';

		foreach(
			Array(
				'search-opener' => Array(
					'class' => 'jvbpd-btn-search1-opener',
					'icon' => 'fa fa-search',
				),
				'map-mobile-switch' => Array(
					'class' => 'jvbpd-btn-map-mobile-switcher jvbpd-map-mobile-switch',
					'icon' => 'fa fa-map-marker',
				),
		) as $menuID => $menuMeta ) {
			$item_buffer[] = sprintf(
				'<a class="%1$s"><i class="%2$s"></i></a>',
				$menuMeta[ 'class' ],
				$menuMeta[ 'icon' ]
			);
		}
		return sprintf( '<li class="%1$s">%2$s</li>', join( ' ', $menu_classes ), join( ' ', $item_buffer ) );
	}


	public function addHeaderSearchMenu( $items, $args=null ) {
		if( $args->theme_location == 'top_nav_menu_right' ) {
			$items .= $this->renderHeaderSearchMenu( $args );
		}
		return $items;
	}

}