<?php
namespace jvbpdelement;  //main namespace

global $jvbpd_cf7;
//$jvbpd_cf7= array_map('basename', glob(dirname( __FILE__ ) . '/widgets/*.php'));
//$jvbpd_cf7= array_map('basename', '/opt/bitnami/apps/wordpress/htdocs/wp-content/plugins/listopia-core/widgets/*.php');
//var_dump ($jvbpd_cf7);

use jvbpdelement\Widgets\jvbpd_cf7;   //path define same as class name of the widget
use jvbpdelement\Widgets\jvbpd_categoryBlock;   //path define same as class name of the widget
use jvbpdelement\Widgets\jvbpd_mailchimp;   //path define same as class name of the widget
use jvbpdelement\Widgets\jvbpd_search_from_listing;   //path define same as class name of the widget
use jvbpdelement\Widgets\jvbpd_block2;   //path define same as class name of the widget
use jvbpdelement\Widgets\jvbpd_lava_grid;   //path define same as class name of the widget
use jvbpdelement\Widgets\jvbpd_lava_post_grid;   //path define same as class name of the widget
use jvbpdelement\Widgets\jvbpd_team_members;   //path define same as class name of the widget
// use jvbpdelement\Widgets\jvbpd_Pricing_Table;   //path define same as class name of the widget

use jvbpdelement\Widgets\jvbpd_single_description;   //path define same as class name of the widget
use jvbpdelement\Widgets\jvbpd_single_amenities;   //path define same as class name of the widget
use jvbpdelement\Widgets\jvbpd_single_faq;   //path define same as class name of the widget
use jvbpdelement\Widgets\jvbpd_single_profile;   //path define same as class name of the widget
use jvbpdelement\Widgets\jvbpd_single_header;   //path define same as class name of the widget
use jvbpdelement\Widgets\jvbpd_single_title_line;   //path define same as class name of the widget
use jvbpdelement\Widgets\jvbpd_single_spyscroll;   //path define same as class name of the widget
use jvbpdelement\Widgets\jvbpd_single_review;   //path define same as class name of the widget
use jvbpdelement\Widgets\jvbpd_single_buttons;   //path define same as class name of the widget
use jvbpdelement\Widgets\jvbpd_single_contact_info;   //path define same as class name of the widget
use jvbpdelement\Widgets\jvbpd_single_small_map;   //path define same as class name of the widget
use jvbpdelement\Widgets\jvbpd_single_gallery;   //path define same as class name of the widget
use jvbpdelement\Widgets\jvbpd_single_working_hours;   //path define same as class name of the widget

use jvbpdelement\Widgets\jvbpd_pracf;   //path define same as class name of the widget

use jvbpdelement\Widgets\jvbpd_map_filter_btns;   //path define same as class name of the widget
use jvbpdelement\Widgets\jvbpd_map_maps;   //path define same as class name of the widget
use jvbpdelement\Widgets\jvbpd_map_amenities;   //path define same as class name of the widget
use jvbpdelement\Widgets\jvbpd_map_listing_blocks;   //path define same as class name of the widget
use jvbpdelement\Widgets\jvbpd_map_more_tax;   //path define same as class name of the widget
/*
use jvbpdelement\Widgets\jvbpd_map_list_filters;   //path define same as class name of the widget
use jvbpdelement\Widgets\jvbpd_map_list_listing_blocks;   //path define same as class name of the widget
*/


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


// Add a custom category for panel widgets
add_action( 'elementor/init', function() {
   \Elementor\Plugin::$instance->elements_manager->add_category(
   	'jvbpd-elements',                 // the name of the category
   	[
   		'title' => esc_html__( 'JAVO', 'jvfrmtd' ),
   		'icon' => 'fa fa-header', //default icon
   	],
   	1 // position
   );
   \Elementor\Plugin::$instance->elements_manager->add_category(
   	'jvbpd-single-listing',                 // the name of the category
   	[
   		'title' => esc_html__( 'Javo Single Listing', 'jvfrmtd' ),
   		'icon' => 'fa fa-header', //default icon
   	],
   	1 // position
   );
   \Elementor\Plugin::$instance->elements_manager->add_category(
   	'jvbpd-map-page',                 // the name of the category
   	[
   		'title' => esc_html__( 'Javo Map Page', 'jvfrmtd' ),
   		'icon' => 'fa fa-header', //default icon
   	],
   	1 // position
   );
} );




/**
 * Main Plugin Class
 *
 * Register new elementor widget.
 *
 * @since 1.0.0
 */
class Plugin {

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */

	public function __construct() {
		$this->add_actions();
	}


	/**
	 * Add Actions
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 */
	private function add_actions() {
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'on_widgets_registered' ] );

	}

	/**
	 * On Widgets Registered
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function on_widgets_registered() {
		$this->includes();
		$this->register_widget();
	}

	/**
	 * Includes
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 */
	private function includes() {
		global $jvbpd_cf7;              //include the widgets here
		//require __DIR__ . '/helper/helper.php';


		require jvlynkCore()->widget_path .'/helper.php';
		require jvlynkCore()->widget_path .'/jvbpd-section-cf7.php';
		require jvlynkCore()->widget_path .'/category-block.php';
		require jvlynkCore()->widget_path .'/mail-chimp.php';
		require jvlynkCore()->widget_path .'/search-form-listing.php';

		require jvlynkCore()->widget_path .'/block2.php';

		require jvlynkCore()->widget_path .'/lava-grid.php';
		require jvlynkCore()->widget_path .'/lava-post-grid.php';
		require jvlynkCore()->widget_path .'/team-members.php';

		require jvlynkCore()->widget_path .'/listopia/single-listing-description.php';
		require jvlynkCore()->widget_path .'/listopia/single-listing-amenities.php';
		require jvlynkCore()->widget_path .'/listopia/single-listing-faq.php';
		require jvlynkCore()->widget_path .'/listopia/single-header.php';
		require jvlynkCore()->widget_path .'/listopia/single-title-line.php';
		require jvlynkCore()->widget_path .'/listopia/single-profile.php';
		require jvlynkCore()->widget_path .'/listopia/single-spyscroll.php';
		require jvlynkCore()->widget_path .'/listopia/single-review.php';
		require jvlynkCore()->widget_path .'/listopia/single-buttons.php';
		require jvlynkCore()->widget_path .'/listopia/single-contact-info.php';
		require jvlynkCore()->widget_path .'/listopia/single-small-map.php';
		require jvlynkCore()->widget_path .'/listopia/single-gallery.php';
		require jvlynkCore()->widget_path .'/listopia/single-working-hours.php';

		require jvlynkCore()->widget_path .'/listopia/custom-widgets.php';

		require jvlynkCore()->widget_path .'/listopia/map-filter-btns.php';
		require jvlynkCore()->widget_path .'/listopia/map-maps.php';
		require jvlynkCore()->widget_path .'/listopia/map-amenities.php';
		require jvlynkCore()->widget_path .'/listopia/map-listing-blocks.php';
		require jvlynkCore()->widget_path .'/listopia/map-more-tax.php';

		/*
		require jvlynkCore()->widget_path .'/listopia/map-list-filters.php';
		require jvlynkCore()->widget_path .'/listopia/map-list-listing-block.php'; */

		//foreach($jvbpd_cf7 as $key => $value){
   			//require __DIR__ . '/'.$value;
   			//require load_files()->widget_path .'/'.$value;
			  //echo "$key is at $value";

		//}
	}

	/**
	 * Register Widget
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 */
	private function register_widget() {
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_cf7() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_categoryBlock() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_mailchimp() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_search_from_listing() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_block2() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_team_members() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_single_description() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_single_amenities() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_single_faq() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_single_profile() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_single_title_line() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_single_review() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_single_contact_info() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_single_small_map() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_single_gallery() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_single_working_hours() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_map_filter_btns() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_map_amenities() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_map_listing_blocks() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_map_more_tax() );
		/*
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_map_list_filters() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_map_list_listing_blocks() ); */

		//\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_lava_grid() );
		//\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_lava_post_grid() );
		//\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_Pricing_Table() );
		//\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_pracf() );
		//\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_single_buttons() );
		//\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_single_spyscroll() );
		//\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_single_header() );
		//\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new jvbpd_map_maps() );
	}
}

new Plugin();
