<?php

add_action( 'init', 'jvbpd_core_bp_dir_init', 8 );
function jvbpd_core_bp_dir_init() {
	require_once( jvlynkCore()->path . '/dir/class/class-bp-ext.php' );
	Jvbpd_bp_dir_ext::getInstance();
}