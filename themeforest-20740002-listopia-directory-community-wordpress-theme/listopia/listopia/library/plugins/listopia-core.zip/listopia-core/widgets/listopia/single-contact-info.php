<?php

/*
Widget Name: Livemesh Team Members
Description: Display a list of your team members optionally in a multi-column grid.
Author: LiveMesh
Author URI: https://www.livemeshthemes.com
*/

namespace jvbpdelement\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;

use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly


class jvbpd_single_contact_info extends Widget_Base {

	public function get_name() {
		return 'jvbpd-single-contact-info';
	}

	public function get_title() {
		return 'Contact Info';   // title to show on elementor
	}

	public function get_icon() {
		return 'fa fa-info-circle';    //   eicon-posts-ticker-> eicon ow asche icon to show on elelmentor
	}

	public function get_categories() {
		return [ 'jvbpd-single-listing' ];    // category of the widget
	}

    protected function _register_controls() {

        $this->start_controls_section(
			'section_general',
			array(
				'label' => esc_html__( 'Contact Info', 'jvfrmtd' ),
			)
		);

		$this->add_control(
		'Des',
			array(
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => sprintf(
					'<div class="elementor-jv-notice" style="background-color:#9b0a46; color:#ffc6c6; padding:10px;"><ul>'.
					'<li class="doc-link">'.
					esc_html__('How to use this widget.','jvfrmtd'). 
					'<a target="_blank" href="http://doc.wpjavo.com/listopia/elementor-single-listing-page/" style="color:#fff;"> ' .  
					esc_html__( 'Documentation', 'jvfrmtd' ) . 
					'</a></li><li>&nbsp;</li>'.
					'<li class="notice">'.
					esc_html__('This widget is for only single listing detail page.', 'jvfrmtd'). 
					'<a target="_blank" href="http://doc.wpjavo.com/listopia/elementor-notice/" style="color:#fff;">' . 
					esc_html__( 'Detail', 'jvfrmtd' ) . 
					'</a><br/></li><li>&nbsp;</li><li>'.
					esc_html__( 'Please do not use in other pages.', 'jvfrmtd' ) .
					'</li></ul></div>'
				)
			)
		);
		$this->end_controls_section();
    }

    protected function render() {

		$settings = $this->get_settings();
		wp_reset_postdata();
		$isPreviewMode = is_admin();

		if( $isPreviewMode) {
			$previewBaseURL = jvlynkCore()->assets_url . '/images/elementor/listipia/';
			$previewURL = $previewBaseURL . 'single-contact-info.jpg';
			printf( '<img src="%s">', esc_url_raw( $previewURL ) );
		}else{
			$this->getContent( $settings, get_post() );
		}
    }

	public function getContent( $settings, $obj ) {
		?>

	<div class="col-md-12 col-xs-12" id="javo-item-condition-section" data-jv-detail-nav>
		<h3 class="page-header"><?php esc_html_e( "Detail", 'listopia' ); ?></h3>
			<!--<h3 class="page-header"><?php esc_html_e( "Item detail", 'listopia' ); ?></h3>-->
		<div class="panel panel-default">
			<div class="panel-body">
			<?php if(''!=(get_post_meta( get_the_ID(), '_website', true ))){ ?>
				<div class="row meta-website">
						<span class="contact-icons"><i class=" jvbpd-icon3-globe"></i></span>
						<span><a href="<?php echo esc_url(esc_attr(get_post_meta( get_the_ID(), '_website', true )));?>" target="_blank"><?php echo esc_html(get_post_meta( get_the_ID(), '_website', true ));?></a></span>
				</div><!-- /.row *website -->
			<?php }
			if(''!=(get_post_meta( get_the_ID(), '_email', true ))){?>
				<!--<div class="row meta-email">
						<span class="contact-icons"><i class=" jvbpd-icon3-envelop"></i></span>
						<span>-->
							<?php
							//$listing_email = esc_html(get_post_meta( get_the_ID(), '_email', true ));
							//printf('<a href="mailto:%s">%s</a>', $listing_email, $listing_email);
							?>
						<!--</span>
				</div>--><!-- /.row *email -->
			<?php }
			if(''!=(get_post_meta( get_the_ID(), '_address', true ))){?>
				<div class="row meta-address">
					<span class="contact-icons"><i class="jvbpd-icon2-location3"></i></span>
					<span><?php echo esc_html(get_post_meta( get_the_ID(), '_address', true ));?></span>
				</div><!-- /.row *address -->
			<?php }
			if(''!=(get_post_meta( get_the_ID(), '_phone1', true ))){?>
				<div class="row meta-phone1">
					<span class="contact-icons"><i class="jvbpd-icon2-tell"></i></span>
					<span><a href="tel://<?php echo esc_html(get_post_meta( get_the_ID(), '_phone1', true ));?>"><?php echo esc_html(get_post_meta( get_the_ID(), '_phone1', true ));?></a></span>
				</div><!-- /.row *phone1-->
			<?php }
			if(''!=(get_post_meta( get_the_ID(), '_phone2', true ))){?>
				<div class="row meta-phone2">
					<span class="contact-icons"><i class="jvbpd-icon3-print"></i></span>
					<span><a href="tel://<?php echo esc_html(get_post_meta( get_the_ID(), '_phone2', true ));?>"><?php echo esc_html(get_post_meta( get_the_ID(), '_phone2', true ));?></a></span>
				</div><!-- /.row *phone2-->
			<?php }
			if($listing_keyword = esc_html(lava_directory_terms( get_the_ID(), 'listing_keyword' ))){?>
				<div class="row meta-keyword">
						<span class="contact-icons"><i class="jvbpd-icon2-bookmark2"></i></span>
						<span><i><?php echo $listing_keyword; ?></i></span>
				</div><!-- /.row *phone2-->
			<?php } ?>
			<?php
			$jvbpd_facebook_link = esc_html(get_post_meta( get_the_ID(), '_facebook_link', true ));
			$jvbpd_twitter_link = esc_html(get_post_meta( get_the_ID(), '_twitter_link', true ));
			$jvbpd_instagram_link = esc_html(get_post_meta( get_the_ID(), '_instagram_link', true ));
			$jvbpd_google_link = esc_html(get_post_meta( get_the_ID(), '_google_link', true ));

			if(!($jvbpd_facebook_link =='' && $jvbpd_twitter_link=='' && $jvbpd_instagram_link=='' && $jvbpd_google_link=='')){
			?>
			<div class="jvbpd_single_listing_social-wrap">
				<?php if ($jvbpd_facebook_link!=''){ ?>
					<a href="<?php echo $jvbpd_facebook_link;?>" target="_blank" class="jvbpd_single_listing_facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
				<?php }
				if ($jvbpd_twitter_link!=''){ ?>
					<a href="<?php echo $jvbpd_twitter_link;?>" target="_blank" class="jvbpd_single_listing_twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
				<?php }
				if ($jvbpd_instagram_link!=''){ ?>
					<a href="<?php echo $jvbpd_instagram_link;?>" target="_blank" class="jvbpd_single_listing_instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
				<?php }
				if ($jvbpd_google_link!=''){ ?>
					<a href="<?php echo $jvbpd_google_link;?>" target="_blank" class="jvbpd_single_listing_google"><i class="fa fa-google" aria-hidden="true"></i></a>
				<?php } ?>
			</div>
		<?php } ?>
			<?php
				if( function_exists( 'lava_directory_claim_button' ) ){
			?>
				<div class="jvbpd_single_claim_wrap">
				<?php
					lava_directory_claim_button(
						Array(
						'class'	=> 'btn btn-block admin-color-setting-hover',
						'label'		=> esc_html__( "Claim", 'listopia' ),
						'icon'		=> false
						)
					);
				?>
				</div>
				<?php
				}
			?>
			</div>
		</div>
	</div>
	<?php
	}
}