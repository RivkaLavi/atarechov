<?php
namespace jvbpdelement\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Style for header
 *
 *
 * @since 1.0.0
 */

class jvbpd_search_from_listing extends Widget_Base {   //this name is added to class-elementor.php of the root folder

	public function get_name() {
		return 'jvbpd-search-from-listing';
	}

	public function get_title() {
		return 'Search Form ( Listing )';   // title to show on elementor
	}

	public function get_icon() {
		return 'eicon-button';    //   eicon-posts-ticker-> eicon ow asche icon to show on elelmentor
	}

	public function get_categories() {
		return [ 'jvbpd-elements' ];    // category of the widget
	}

	/**
	 * A list of scripts that the widgets is depended in
	 * @since 1.3.0
	 **/
protected function _register_controls() {

//start of a control box
		$this->start_controls_section(
			'section_general',
			array(
				'label' => esc_html__( 'Note', 'jvfrmtd' ),
			)
		);

		$this->add_control(
		'Des',
			array(
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => sprintf(
					'<div class="elementor-jv-notice" style="background-color:#9b0a46; color:#ffc6c6; padding:10px;"><ul>'.
					'<li class="doc-link">'.
					esc_html__('How to use this widget.','jvfrmtd'). 
					'<a target="_blank" href="http://doc.wpjavo.com/listopia/elementor-search-form/" style="color:#fff;"> ' . 
					esc_html__( 'Documentation', 'jvfrmtd' ) . 
					'</a></li></ul></div>'
				)
			)
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'section_content', [
				'label' => esc_html__( 'Listing Search Form', 'jvfrmtd' ),   //section name for controler view
			]
		);

		$this->add_control( 'column1', [
			 'label'       => __( 'Column1', 'jvfrmtd' ),
			 'type' => Controls_Manager::SELECT,
			 'default' => 'listing_category_with_keyword',
			 'options' => [
				'listing_category_with_keyword'  => __( 'Keyword', 'jvfrmtd' ),
				'listing_location_with_google_search' => __( 'Google', 'jvfrmtd' ),
				'ajax_search' => __( 'Global Search', 'jvfrmtd' ),
			 ],
             'description' => esc_html__('Select a fit image size depends on the columns.','jvfrmtd'),
		  ]
		);

		$this->add_control(
		  'column2', [
			 'label'       => __( 'Column2', 'jvfrmtd' ),
			 'type' => Controls_Manager::SELECT,
			 'default' => 'listing_location_with_google_search',
			 'options' => [
				'listing_location_with_google_search' => __( 'Google', 'jvfrmtd' ),
				'listing_category_with_keyword'  => __( 'Keyword', 'jvfrmtd' ),
				'ajax_search' => __( 'Global Search', 'jvfrmtd' ),
			 ],
             'description' => esc_html__('Select a fit image size depends on the columns.','jvfrmtd'),
		  ]
		);


		$this->add_control(
		  'query_requester', [
			 'label'       => __( 'Please select search result page', 'jvfrmtd' ),
			 'type' => Controls_Manager::SELECT,
			 'default' => '',
			 'options' => array_flip( apply_filters(
				'jvbpd_get_map_templates',
				Array( esc_html__("Default Search Page", 'jvfrmtd') => '' )
			) ),
             'description' => esc_html__('Select a fit image size depends on the columns.','jvfrmtd'),
		  ]
		);
		$this->end_controls_section();
	}

	protected function render() {
		// to show on the fontend
		static $v_veriable=0;
		$settings = $this->get_settings();
		$prepareCode = '[jvbpd_search1 keyword_auto="disable" amenities_field="disable" columns="2" column1="%1$s" column2="%2$s" query_requester="%3$s" break_submit="true"]';
		echo do_shortcode( sprintf( $prepareCode, $settings[ 'column1' ], $settings[ 'column2' ], $settings[ 'query_requester' ] ) );
    }
}
