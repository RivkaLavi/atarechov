<?php

/*
Widget Name: Livemesh Team Members
Description: Display a list of your team members optionally in a multi-column grid.
Author: LiveMesh
Author URI: https://www.livemeshthemes.com
*/

namespace jvbpdelement\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;

use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly


class jvbpd_single_small_map extends Widget_Base {

	public function get_name() {
		return 'jvbpd-single-small-map';
	}

	public function get_title() {
		return 'Small Map';   // title to show on elementor
	}

	public function get_icon() {
		return 'fa fa-map-o';    //   eicon-posts-ticker-> eicon ow asche icon to show on elelmentor
	}

	public function get_categories() {
		return [ 'jvbpd-single-listing' ];    // category of the widget
	}

    protected function _register_controls() {

        $this->start_controls_section(
			'section_general',
			array(
				'label' => esc_html__( 'Small Map', 'jvfrmtd' ),
			)
		);

		$this->add_control(
		'Des',
			array(
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => sprintf(
					'<div class="elementor-jv-notice" style="background-color:#9b0a46; color:#ffc6c6; padding:10px;"><ul>'.
					'<li class="doc-link">'.
					esc_html__('How to use this widget.','jvfrmtd'). 
					'<a target="_blank" href="http://doc.wpjavo.com/listopia/elementor-single-listing-page/" style="color:#fff;"> ' . 
					esc_html__( 'Documentation', 'jvfrmtd' ) . 
					'</a></li><li>&nbsp;</li>'.
					'<li class="notice">'.
					esc_html__('This widget is for only single listing detail page.', 'jvfrmtd'). 
					'<a target="_blank" href="http://doc.wpjavo.com/listopia/elementor-notice/" style="color:#fff;">' . 
					esc_html__( 'Detail', 'jvfrmtd' ) . 
					'</a><br/></li><li>&nbsp;</li><li>'.
					esc_html__( 'Please do not use in other pages.', 'jvfrmtd' ) .
					'</li></ul></div>'
				)
			)
		);
		$this->end_controls_section();
    }

    protected function render() {

		$settings = $this->get_settings();
		$isVisible = false;

		wp_reset_postdata();
		/* Check post type */
		$isPreviewMode = is_admin();
		
		/*If preview, show images */
		if( $isPreviewMode) {
			$previewBaseURL = jvlynkCore()->assets_url . '/images/elementor/listipia/';
			$previewURL = $previewBaseURL . 'single-small-map.png';
			printf( '<img src="%s">', esc_url_raw( $previewURL ) );
		}else{
			$this->getContent( $settings, get_post() );
		}
    }
	
	/* Real output */
	public function getContent( $settings, $obj ) {
		?>
		<div class="" id="javo-item-map-section" data-jv-detail-nav>
			<h3 class="page-header"><?php esc_html_e( "Detail", 'listopia' ); ?></h3>
			<div class="panel panel-default">
				<div class="panel-body">
					<div class="meta-small-map">
						<div class="small-map-container single-lv-map-style" id="lava-single-map-area"></div>
						<div class="lava-single-map-param">
							<input type="hidden" data-map-height="120">
						</div>
						<?php
						printf(
							'<a href="%1$s%2$s,%3$s" target="_blank" class="btn btn-block btn-default" title="%4$s">%4$s</a>',
							esc_url_raw( 'google.com/maps/dir/Current+Location/' ),
							get_post_meta( get_the_ID(), 'lv_listing_lat', true ),
							get_post_meta( get_the_ID(), 'lv_listing_lng', true ),
							esc_html__( "Get a direction", 'listopia' )
						); ?>
					</div>
				</div>
			</div>
		</div>
		<?php
	}
}