<?php

/*
Widget Name: Livemesh Team Members
Description: Display a list of your team members optionally in a multi-column grid.
Author: LiveMesh
Author URI: https://www.livemeshthemes.com
*/

namespace jvbpdelement\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;

use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly


class jvbpd_map_list_filters extends Widget_Base {

	public function get_name() {
		return 'jvbpd-map-list-filters';
	}

	public function get_title() {
		return 'List Type Filter Buttons';   // title to show on elementor
	}

	public function get_icon() {
		return 'fa fa-list-ul';    //   eicon-posts-ticker-> eicon ow asche icon to show on elelmentor
	}

	public function get_categories() {
		return [ 'jvbpd-map-page' ];    // category of the widget
	}

    protected function _register_controls() {

        $this->start_controls_section(
			'section_general',
			array(
				'label' => esc_html__( 'Map List Filters', 'jvfrmtd' ),
			)
		);

		$this->add_control(
		'Des',
			array(
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => sprintf(
					'<div class="elementor-jv-notice" style="background-color:#9b0a46; color:#ffc6c6; padding:10px;"><ul>'.
					'<li class="doc-link">'.
					esc_html__('How to use this widget.','jvfrmtd').
					'<a target="_blank" href="http://doc.wpjavo.com/listopia/elementor-filter-buttons-for-map//" style="color:#fff;"> ' .
					esc_html__( 'Documentation', 'jvfrmtd' ) .
					'</a></li><li>&nbsp;</li>'.
					'<li class="notice">'.
					esc_html__('This widget is for only map page.', 'jvfrmtd').
					'<a target="_blank" href="http://doc.wpjavo.com/listopia/elementor-notice/" style="color:#fff;"> ' .
					esc_html__( 'Detail', 'jvfrmtd' ) .
					'</a><br/></li><li>&nbsp;</li><li>'.
					esc_html__( 'Please do not use in other pages.', 'jvfrmtd' ) .
					'</li></ul></div>'
				)
			)
		);
		$this->end_controls_section();

		$this->start_controls_section( 'section_content', Array(
			'label' => esc_html__( 'Filter Setting', 'jvfrmtd' ),   //section name for controler view
		) );


		$this->add_control(
			'filters',
			Array(
				'label' => __( 'Menu Filters', 'jvfrmtd' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => Array(
					Array(
						'name' => 'callback',
						'label' => __( 'Filter', 'jvfrmtd' ),
						'type' => Controls_Manager::SELECT,
						'options' => Array(
							'' => esc_html__( 'Select a filter', 'jvfrmtd' ),
							'address' => __('Address Search with Distance bar', 'jvfrmtd'),
							'category' => __('Category', 'jvfrmtd'),
							'location' => __('Location', 'jvfrmtd'),
							'amenities' => __('Amenities', 'jvfrmtd'),
							'more_taxonomy' => __('More Taxonomies', 'jvfrmtd'),
							'features' => __('Features', 'jvfrmtd'),
						),
					),
					Array(
						'name' => 'more_taxonomy',
						'label' => esc_html__( "More Taxonomy", 'jvfrmtd' ),
						'type' => Controls_Manager::SELECT,
						'default' => '',
						'options' => $this->getMoreTaxonomies(),
						'condition' => Array(
							'callback' => 'more_taxonomy',
						),
					),
					Array(
						'name' => 'filter_title',
						'label' => esc_html__( "Filter Title", 'jvfrmtd' ),
						'type' => Controls_Manager::TEXT,
						'default' => '',
						'label_block' => true,
					),
				),
				'title_field' => 'Button : {{{ filter_title }}}',
			)
		);

        $this->end_controls_section();
    }

    protected function render() {

		$settings = $this->get_settings();
		wp_reset_postdata();
		$isPreviewMode = is_admin();
		$isPreviewMode = false;

		if( $isPreviewMode) {
			$previewBaseURL = jvlynkCore()->assets_url . '/images/elementor/listipia/';
			$previewURL = $previewBaseURL . 'single-button.jpg';
			printf( '<img src="%s">', esc_url_raw( $previewURL ) );
		}else{
			$this->getContent( $settings, get_post() );
		}
    }

	public function getContent( $settings, $obj ) {
		?>
		<div id="map-list-style-wraps" <?php jvbpd_map_class( 'container' ); ?>>
			<?php do_action( 'jvbpd_' . jvlynkCore()->getSlug() . '_map_list_wrap_before', $GLOBALS[ 'post' ] ); ?>
			<div class="jvbpd_map_list_sidebar_wrap">
				<?php
				$arrCallBack = $settings[ 'filters' ];
				if( !empty( $arrCallBack ) && is_array( $arrCallBack ) ) {
					foreach( $arrCallBack as $strCallBack ) {
						if( method_exists( $this, $strCallBack[ 'callback' ] ) ) {
							call_user_func( Array( $this, $strCallBack[ 'callback' ] ), $strCallBack );
						}
					}
				}?>
			</div>
		</div>
		<?php
	}

	public function getMoreTaxonomies() {
		$output = Array( '' => esc_html__( "Select a taxonomy", 'jvfrmtd' ) );
		if( function_exists( 'javo_moreTax' ) ) {
			$taxonomies = javo_moreTax()->admin->getMoreTaxonomies();
			if( is_array( $taxonomies ) ) {
				foreach( $taxonomies as $taxonomy ) {
					$output[ $taxonomy[ 'name' ] ] = $taxonomy[ 'label' ];
				}
			}
		}
		return $output;
	}


	/*
		'address' => __('Address Search with Distance bar', 'jvfrmtd'),
		'category' => __('Category', 'jvfrmtd'),
		'location' => __('Location', 'jvfrmtd'),
		'amenities' => __('Amenities', 'jvfrmtd'),
		'more_taxonomy' => __('More Taxonomies', 'jvfrmtd'),
		'features' => __('Features', 'jvfrmtd'),
	*/

	public function address( $settings=Array() ) {
		$label = isset( $settings[ 'filter_title' ] ) ? $settings[ 'filter_title' ] : esc_html__( "Address", 'jvfrmtd' );
		?>
		<div id="<?php echo esc_attr( 'filter-address' ); ?>" class="panel panel-default panel-accordion panel-checkbox panel-more">
			<div class="panel-heading" data-toggle="collapse" data-target="<?php echo esc_attr( '#filter-' . $settings[ '_id' ] ); ?>">
				<h3 class="panel-title"><?php echo esc_html( $label ); ?></h3><span class="toggle chevron"></span>
			</div>
			<div class="panel-collapse collapse show" id="<?php echo esc_attr( 'filter-' . $settings[ '_id' ] ); ?>">
				<div class="panel-body">
					<?php
					$arrJavoOutput = Array();
					$arrJavoOutput[] = "<div class=\"input-group\">";
					$arrJavoOutput[]			= "
						<span class=\"input-group-btn\">
							<button class=\"btn btn-primary admin-color-setting my-position-trigger\">
								<i class=\"fa fa-compass\"></i>
							</button>
						</span>";
					$arrJavoOutput[] = sprintf(
						"<input type=\"text\" id=\"%s\" class=\"%s\" value=\"%s\" placeholder=\"%s\">"
						,'address'
						, ''
						, ''
						, ''
					);
					$arrJavoOutput[] = "</div>";
					echo join( false, $arrJavoOutput ); ?>
				</div>
			</div>
		</div>
		<?php
	}

	public function category( $settings=Array() ) {
		$label = isset( $settings[ 'filter_title' ] ) ? $settings[ 'filter_title' ] : esc_html__( "Category", 'jvfrmtd' );
		?>
		<div id="<?php echo esc_attr( 'filter-address' ); ?>" class="panel panel-default panel-accordion panel-checkbox panel-more">
			<div class="panel-heading" data-toggle="collapse" data-target="<?php echo esc_attr( '#filter-' . $settings[ '_id' ] ); ?>">
				<h3 class="panel-title"><?php echo esc_html( $label ); ?></h3><span class="toggle chevron"></span>
			</div>
			<div class="panel-collapse collapse show" id="<?php echo esc_attr( 'filter-' . $settings[ '_id' ] ); ?>">
				<div class="panel-body">
					<?php
					if( taxonomy_exists( 'listing_category' ) ) {
						$arrJavoOutput[]	= "
							<select
								name=\"list_filter[listing_category]\"
								data-tax=\"listing_category\"
								class=\"form-control\">";
							$arrJavoOutput[]	= "<option value=''>Select a category</option>";
							$arrJavoOutput[]	= apply_filters(
								'jvbpd_get_selbox_child_term_lists'
								, 'listing_category'
								, null
								, 'select'
								, false
								, 0
								, 0
								, '-'
							);
						$arrJavoOutput[]	= "</select>";
					}
					echo join( false, $arrJavoOutput ); ?>
				</div>
			</div>
		</div>
		<?php
	}

	public function amenities( $settings=Array() ) {
		$label = isset( $settings[ 'filter_title' ] ) ? $settings[ 'filter_title' ] : esc_html__( "Amenities", 'jvfrmtd' );
		?>
		<div id="<?php echo esc_attr( 'filter-address' ); ?>" class="panel panel-default panel-accordion panel-checkbox panel-more">
			<div class="panel-heading" data-toggle="collapse" data-target="<?php echo esc_attr( '#filter-' . $settings[ '_id' ] ); ?>">
				<h3 class="panel-title"><?php echo esc_html( $label ); ?></h3><span class="toggle chevron"></span>
			</div>
			<div class="panel-collapse collapse show" id="<?php echo esc_attr( 'filter-' . $settings[ '_id' ] ); ?>">
				<div class="panel-body">
					<?php
					if( taxonomy_exists( 'listing_amenities' ) &&
						$terms = get_terms( 'listing_amenities', Array( 'hide_empty' => 0 ) )
					) foreach( $terms as $term ) {
						$arrJavoOutput[]			= "<div class=\"checkbox\">";
							$arrJavoOutput[]		= "<label>";
								$arrJavoOutput[]	= "<span class=\"check\"></span>";
								$arrJavoOutput[]	= "<input type=\"checkbox\" name=\"jvbpd_list_multiple_filter\" value=\"{$term->term_id}\"" . ' ';
								$arrJavoOutput[]	= "class=\"tclick\" data-tax=\"{$term->taxonomy}\"";
								$arrJavoOutput[]	= checked( in_Array( $term->term_id, Array() ) , true, false );
								$arrJavoOutput[]	= ">";

								$arrJavoOutput[]	= $term->name;
							$arrJavoOutput[]		= "</label>";
						$arrJavoOutput[]			= "</div>";
					}
					echo join( false, $arrJavoOutput ); ?>
				</div>
			</div>
		</div>
		<?php
	}

	public function more_taxonomy( $settings=Array() ) {
		$label = isset( $settings[ 'filter_title' ] ) ? $settings[ 'filter_title' ] : esc_html__( "More Taxonomy", 'jvfrmtd' );
		?>
		<div id="<?php echo esc_attr( 'filter-address' ); ?>" class="panel panel-default panel-accordion panel-checkbox panel-more">
			<div class="panel-heading" data-toggle="collapse" data-target="<?php echo esc_attr( '#filter-' . $settings[ '_id' ] ); ?>">
				<h3 class="panel-title"><?php echo esc_html( $label ); ?></h3><span class="toggle chevron"></span>
			</div>
			<div class="panel-collapse collapse show" id="<?php echo esc_attr( 'filter-' . $settings[ '_id' ] ); ?>">
				<div class="panel-body">
					<?php
					if( taxonomy_exists( $settings[ 'more_taxonomy' ] ) ) {
						$arrJavoOutput[]	= "
							<select
								name=\"list_filter[{$settings[ 'more_taxonomy' ]}]\"
								data-tax=\"{$settings[ 'more_taxonomy' ]}\"
								class=\"form-control\">";
							$arrJavoOutput[]	= "<option value=''>Select a category</option>";
							$arrJavoOutput[]	= apply_filters(
								'jvbpd_get_selbox_child_term_lists'
								, $settings[ 'more_taxonomy' ]
								, null
								, 'select'
								, false
								, 0
								, 0
								, '-'
							);
						$arrJavoOutput[]	= "</select>";
						echo join( false, $arrJavoOutput );
					}
					 ?>
				</div>
			</div>
		</div>
		<?php
	}

}