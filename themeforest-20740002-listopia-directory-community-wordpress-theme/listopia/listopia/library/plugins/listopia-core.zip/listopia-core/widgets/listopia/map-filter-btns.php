<?php

/*
Widget Name: Livemesh Team Members
Description: Display a list of your team members optionally in a multi-column grid.
Author: LiveMesh
Author URI: https://www.livemeshthemes.com
*/

namespace jvbpdelement\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;

use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly


class jvbpd_map_filter_btns extends Widget_Base {

	public function get_name() {
		return 'jvbpd-map-rating-btn';
	}

	public function get_title() {
		return 'Filter Buttons';   // title to show on elementor
	}

	public function get_icon() {
		return 'fa fa-list-ul';    //   eicon-posts-ticker-> eicon ow asche icon to show on elelmentor
	}

	public function get_categories() {
		return [ 'jvbpd-map-page' ];    // category of the widget
	}

    protected function _register_controls() {

        $this->start_controls_section(
			'section_general',
			array(
				'label' => esc_html__( 'Map Filter Buttons Note', 'jvfrmtd' ),
			)
		);

		$this->add_control(
		'Des',
			array(
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => sprintf(
					'<div class="elementor-jv-notice" style="background-color:#9b0a46; color:#ffc6c6; padding:10px;"><ul>'.
					'<li class="doc-link">'.
					esc_html__('How to use this widget.','jvfrmtd').
					'<a target="_blank" href="http://doc.wpjavo.com/listopia/elementor-filter-buttons-for-map//" style="color:#fff;"> ' .
					esc_html__( 'Documentation', 'jvfrmtd' ) .
					'</a></li><li>&nbsp;</li>'.
					'<li class="notice">'.
					esc_html__('This widget is for only map page.', 'jvfrmtd').
					'<a target="_blank" href="http://doc.wpjavo.com/listopia/elementor-notice/" style="color:#fff;"> ' .
					esc_html__( 'Detail', 'jvfrmtd' ) .
					'</a><br/></li><li>&nbsp;</li><li>'.
					esc_html__( 'Please do not use in other pages.', 'jvfrmtd' ) .
					'</li></ul></div>'
				)
			)
		);
		$this->end_controls_section();

		$this->start_controls_section( 'section_content', Array(
			'label' => esc_html__( 'Filter Setting', 'jvfrmtd' ),   //section name for controler view
		) );


		$this->add_control(
			'filters',
			Array(
				'label' => __( 'Menu Filters', 'jvfrmtd' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => Array(
					Array(
						'name' => 'callback',
						'label' => __( 'Select a Button', 'jvfrmtd' ),
						'type' => Controls_Manager::SELECT,
						'options' => Array(
							'rating' => __('Rating', 'jvfrmtd'),
							'sort' => __('Sort by', 'jvfrmtd'),
							'most_reviewed' => __('Most Reviewed', 'jvfrmtd'),
							'favroites' => __('Favorites', 'jvfrmtd'),
							'open_hour' => __('Open Now', 'jvfrmtd'),
							'module_type_switcher' => __('Module Type Switcher', 'jvfrmtd'),
							'near_me' => __('Near Me', 'jvfrmtd'),
						),
					),
					Array(
						'name' => 'filter_title',
						'label' => esc_html__( "Filter Title", 'jvfrmtd' ),
						'type' => Controls_Manager::TEXT,
						'default' => '',
						'label_block' => true,
					),
				),
				'title_field' => 'Button : {{{ filter_title }}}',
			)
		);

        $this->end_controls_section();
    }

    protected function render() {

		$settings = $this->get_settings();
		wp_reset_postdata();
		$isPreviewMode = is_admin();
		$isPreviewMode = false;

		if( $isPreviewMode) {
			$previewBaseURL = jvlynkCore()->assets_url . '/images/elementor/listipia/';
			$previewURL = $previewBaseURL . 'single-button.jpg';
			printf( '<img src="%s">', esc_url_raw( $previewURL ) );
		}else{
			$this->getContent( $settings, get_post() );
		}
    }

	public function rating( $settings=Array() ) {
		if( function_exists( 'lv_directoryReview' ) ) {
			?>
			<div class="btn-group menu-item" data-menu-filter="rating">
				<button class="btn dropdown-toggle btn-sm" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					<?php esc_html_e( "Rating", 'jvfrmtd' ); ?>
				</button>
				<div class="dropdown-menu">
					<div class="dropdown-item" data-value="high"><?php esc_html_e( "By High Rated", 'jvfrmtd'); ?></div>
					<div class="dropdown-item" data-value="low"><?php esc_html_e( "By Low Rated", 'jvfrmtd'); ?></div>
					<div class="dropdown-divider"></div>
					<?php
					for( $intRateNumeric=5; $intRateNumeric>=1;$intRateNumeric-- ) {
						printf( '<div class="dropdown-item" data-value="%1$s">%1$s</div>', $intRateNumeric );
					} ?>
				</div>
			</div>
			<?php
		}
	}

	public function sort( $settings=Array() ) {
		$label = isset( $settings[ 'filter_title' ] ) ? $settings[ 'filter_title' ] : esc_html__( "Sort By", 'jvfrmtd' );
		?>
		<div class="btn-group menu-item" data-menu-filter="order">
			<button class="btn dropdown-toggle btn-sm" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				<?php echo esc_html( $label ); ?>
			</button>
			<div class="dropdown-menu">
				<div class="dropdown-item desc" data-value="name" data-type="desc">
					<?php esc_html_e( "Name", 'jvfrmtd'); ?>
					<span class="glyphicon glyphicon-arrow-up pull-right asc"></span>
					<span class="glyphicon glyphicon-arrow-down pull-right desc"></span>
				</div>
				<div class="dropdown-item desc" data-value="date" data-type="desc">
					<?php esc_html_e( "Date", 'jvfrmtd'); ?>
					<span class="glyphicon glyphicon-arrow-up pull-right asc"></span>
					<span class="glyphicon glyphicon-arrow-down pull-right desc"></span>
				</div>
			</div>
		</div>
		<?php
	}

	public function most_reviewed( $settings=Array() ) {
		$label = isset( $settings[ 'filter_title' ] ) ? $settings[ 'filter_title' ] : esc_html__( "Most reviewed", 'jvfrmtd' );
		?>
		<div class="btn-group menu-item" data-menu-filter="reviewed">
			<button class="btn btn-sm" type="button" data-toggle="button" data-value="1" aria-haspopup="true" aria-expanded="false">
				<?php echo esc_html( $label ); ?>
			</button>
		</div>
		<?php
	}

	public function favroites( $settings=Array() ) {
		$label = isset( $settings[ 'filter_title' ] ) ? $settings[ 'filter_title' ] : esc_html__( "Favorites", 'jvfrmtd' );
		?>
		<div class="btn-group menu-item" data-menu-filter="favorite">
			<button class="btn btn-sm" type="button" data-toggle="button" data-value="1" aria-haspopup="true" aria-expanded="false">
				<?php echo esc_html( $label ); ?>
			</button>
		</div>
		<?php
	}

	public function near_me( $settings=Array() ) {
		$label = isset( $settings[ 'filter_title' ] ) ? $settings[ 'filter_title' ] : esc_html__( "Near Me", 'jvfrmtd' );
		?>
		<div class="btn-group menu-item" data-menu-filter="nearme">
			<button class="btn dropdown-toggle btn-sm" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				<?php echo esc_html( $label ); ?>
			</button>
			<div class="dropdown-menu">
				<div class="jvbpd-map-distance-bar-wrap">
					<button type="button" data-close="">
						<i class="fa fa-remove"></i>
					</button>
					<div class="javo-geoloc-slider"></div>
				</div>
			</div>
		</div>
		<?php
	}

	public function open_hour( $settings=Array() ) {
		$label = isset( $settings[ 'filter_title' ] ) ? $settings[ 'filter_title' ] : esc_html__( "Open now", 'jvfrmtd' );
		?>
		<div class="btn-group menu-item" data-menu-filter="openhour">
			<button class="btn btn-sm" type="button" data-toggle="button" data-value="1" aria-haspopup="true" aria-expanded="false">
				<?php echo esc_html( $label ); ?>
			</button>
		</div>
		<?php
	}

	public function module_type_switcher( $settings=Array() ) {
		?>
		<div class='btn-group module-switcher' data-toggle="buttons">
			<label class="btn active">
				<input type="radio" name="module_switcher" value="grid" checked="checked">
				<span class='fa fa-th'></span>
			</label>
			<label class="btn">
				<input type="radio" name="module_switcher" value="list">
				<span class='fa fa-list'></span>
			</label>
		</div>
		<?php
	}

	public function getContent( $settings, $obj ) {
		?>
		<div class="map-filter-menu">
			<?php
			$arrCallBack = $settings[ 'filters' ];
			if( !empty( $arrCallBack ) && is_array( $arrCallBack ) ) {
				foreach( $arrCallBack as $strCallBack ) {
					if( method_exists( $this, $strCallBack[ 'callback' ] ) ) {
						call_user_func( Array( $this, $strCallBack[ 'callback' ] ), $strCallBack );
					}
				}
			}?>
		</div>
		<?php
	}
}