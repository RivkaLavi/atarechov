<?php

/*
Widget Name: Livemesh Team Members
Description: Display a list of your team members optionally in a multi-column grid.
Author: LiveMesh
Author URI: https://www.livemeshthemes.com
*/

namespace jvbpdelement\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;

use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly


class jvbpd_single_faq extends Widget_Base {

	public function get_name() {
		return 'jvbpd-team-members';
	}

	public function get_title() {
		return 'FaQ';   // title to show on elementor
	}

	public function get_icon() {
		return 'fa fa-question-circle-o';    //   eicon-posts-ticker-> eicon ow asche icon to show on elelmentor
	}

	public function get_categories() {
		return [ 'jvbpd-single-listing' ];    // category of the widget
	}

    protected function _register_controls() {

       $this->start_controls_section(
			'section_general',
			array(
				'label' => esc_html__( 'FAQ', 'jvfrmtd' ),
			)
		);

		$this->add_control(
		'Des',
			array(
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => sprintf(
					'<div class="elementor-jv-notice" style="background-color:#9b0a46; color:#ffc6c6; padding:10px;"><ul>'.
					'<li class="doc-link">'.
					esc_html__('How to use this widget.','jvfrmtd'). 
					'<a target="_blank" href="http://doc.wpjavo.com/listopia/elementor-single-listing-page/" style="color:#fff;"> ' .  
					esc_html__( 'Documentation', 'jvfrmtd' ) . 
					'</a></li><li>&nbsp;</li>'.
					'<li class="notice">'.
					esc_html__('This widget is for only single listing detail page.', 'jvfrmtd'). 
					'<a target="_blank" href="http://doc.wpjavo.com/listopia/elementor-notice/" style="color:#fff;">' . 
					esc_html__( 'Detail', 'jvfrmtd' ) . 
					'</a><br/></li><li>&nbsp;</li><li>'.
					esc_html__( 'Please do not use in other pages.', 'jvfrmtd' ) .
					'</li></ul></div>'
				)
			)
		);
		$this->end_controls_section();

    }

    protected function render() {

		$settings = $this->get_settings();
		$isVisible = false;

		wp_reset_postdata();
		$isPreviewMode = is_admin();

		if( class_exists( 'lvjr_Faq' ) ) {
			$objFaq = new \lvjr_Faq( get_the_ID() );
			if( !empty( $objFaq->values ) ) {
				$isVisible = true;
			}
		}

		if( $isPreviewMode ) {
			$previewBaseURL = jvlynkCore()->assets_url . '/images/elementor/listipia/';
			$previewURL = $previewBaseURL . 'single-faq.jpg';
			printf( '<img src="%s">', esc_url_raw( $previewURL ) );
		}else{
			if( $isVisible ) {
				$this->getContent( $settings, $objFaq );
			}
		}
    }

	public function getContent( $settings, $obj ) {
		?>
		<div class="detail-block faq">
			<!--<h3><?php esc_html_e( "FAQ", 'listopia' ); ?></h3>-->

			<div class="panel-group" id="lava_faq" role="tablist" aria-multiselectable="true">
				<?php
				foreach( (array) $obj->values as $intIndex => $arrFaQ ) {

					printf( '
						<div class="panel panel-default">
							<div class="panel-heading" role="tab">
								<i class="jvbpd-icon2-arrow-right"></i>
								<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#lava_faq" href="#%4$s" aria-expanded="true" aria-controls="%4$s">%1$s</a>
								</h4>
							</div>
							<div id="%4$s" class="panel-collapse collapse%3$s" role="tabpanel">
								<div class="panel-body"><div class="lava_faq_content">%2$s</div></div>
							</div>
						</div>',
						$arrFaQ[ 'frequently' ], $arrFaQ[ 'question' ],
						( $intIndex == 0 ? ' show' : '' ), 'lavaFaQ' . $intIndex
					);
				}?>
			</div>
		</div><!-- detail-block contact -->
		<?php
	}
}