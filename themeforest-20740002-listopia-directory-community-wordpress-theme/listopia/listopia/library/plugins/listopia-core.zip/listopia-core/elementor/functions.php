<?php
/**
 * Header Footer Elementor Function
 *
 * @package  header-footer-elementor
 */

/**
 * Checks if Header is enabled from HFE.
 *
 * @since  1.0.2
 * @return bool True if header is enabled. False if header is not enabled
 */
function jvbpd_header_enabled() {
	$header_id = Jvbpd_Listing_Elementor::get_settings( 'single_listing_page', '' );

	if ( '' !== $header_id ) {
		return true;
	}

	return false;
}

/**
 * Checks if Footer is enabled from HFE.
 *
 * @since  1.0.2
 * @return bool True if header is enabled. False if header is not enabled.
 */
function jvbpd_footer_enabled() {
	$footer_id = Jvbpd_Listing_Elementor::get_settings( 'listing_search', '' );

	if ( '' !== $footer_id ) {
		return true;
	}

	return false;
}

/**
 * Checks if Footer is enabled from HFE.
 *
 * @since  1.0.2
 * @return bool True if header is enabled. False if header is not enabled.
 */
function jvbpd_listing_archive_enabled() {
	$listing_archive_id = Jvbpd_Listing_Elementor::get_settings( 'type_listing_archive', '' );

	if ( '' !== $listing_archive_id ) {
		return true;
	}

	return false;
}

/**
 * Get HFE Header ID
 *
 * @since  1.0.2
 * @return (String|boolean) header id if it is set else returns false.
 */
function get_jvbpd_header_id() {
	$header_id = Jvbpd_Listing_Elementor::get_settings( 'single_listing_page', '' );

	if ( '' !== $header_id ) {
		return $header_id;
	}

	return false;
}

/**
 * Get HFE Footer ID
 *
 * @since  1.0.2
 * @return (String|boolean) header id if it is set else returns false.
 */
function get_jvbpd_footer_id() {
	$footer_id = Jvbpd_Listing_Elementor::get_settings( 'listing_search', '' );

	if ( '' !== $footer_id ) {
		return $footer_id;
	}

	return false;
}

/**
 * Get HFE Footer ID
 *
 * @since  1.0.2
 * @return (String|boolean) header id if it is set else returns false.
 */
function get_jvbpd_listing_archive_id() {
	$listing_archive_id = Jvbpd_Listing_Elementor::get_settings( 'type_listing_archive', '' );

	if ( '' !== $listing_archive_id ) {
		return $listing_archive_id;
	}

	return false;
}

/**
 * Display header markup.
 *
 * @since  1.0.2
 */
function jvbpd_single_core_render() {

	if ( false == apply_filters( 'enable_jvbpd_render_header', '__return_true' ) ) {
		return;
	}?>
		<div class="jv-content">
			<?php Jvbpd_Listing_Elementor::get_header_content(); ?>
		</div>
	<?php

}

/**
 * Display footer markup.
 *
 * @since  1.0.2
 */

/*
function jvbpd_render_footer() {
	if ( false == apply_filters( 'enable_jvbpd_render_footer', '__return_true' ) ) {
		return;
	}?>
		<?php Jvbpd_Listing_Elementor::get_footer_content(); ?>
	<?php
} */


/**
 * Display header markup.
 *
 * @since  1.0.2
 */
function jvbpd_listing_achive_render() {

	if ( false == apply_filters( 'enable_jvbpd_render_listing_archive', '__return_true' ) ) {
		return;
	}

	?>
		<div class="jv-content">
			<?php Jvbpd_Listing_Elementor::get_listing_archive_content(); ?>
		</div>

	<?php

}
