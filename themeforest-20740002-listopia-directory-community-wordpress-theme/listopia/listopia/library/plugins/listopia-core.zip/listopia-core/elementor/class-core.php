<?php
/**
 * Load the class loader.
 */

if( ! function_exists( 'jvbpd_core_elementor_init' ) ) {
	add_action( 'init', 'jvbpd_core_elementor_init' );
	function jvbpd_core_elementor_init() {
		require_once( jvlynkCore()->elementor_path . '/class-main.php' );
		require_once( jvlynkCore()->elementor_path . '/helper-jv-group-control-box.php' );
		require_once( jvlynkCore()->elementor_path . '/class-elements-tool.php' );
		new Jvbpd_Listing_Elementor();
		if( function_exists( 'jvbpd_add_group_control' ) ) {
			add_action( 'elementor/controls/controls_registered', 'jvbpd_add_group_control' );
		}
	}
}

if( ! function_exists( 'jvbpd_add_group_control' ) && class_exists( 'JV_Group_Contro_Box_Style' ) ) {
	function jvbpd_add_group_control( $controls_manager ) {
		$grouped = array(
			'jv-box-style' => 'JV_Group_Control_Box_Style',
		);

		foreach ( $grouped as $control_id => $class_name ) {
			$controls_manager->add_group_control( $control_id, new $class_name() );
		}
	}
}

if( ! function_exists( 'jvbpd_global_page_setting_search_in_header' ) ) {
	add_action( 'elementor/element/page-settings/section_page_settings/before_section_end', 'jvbpd_global_page_setting_search_in_header', 99 );
	function jvbpd_global_page_setting_search_in_header( $page ) {
		$page->add_control(
			'search_shortcode_in_header', Array(
				'label' => __( 'Display Search Form in header', 'jvfrmtd' ),
				'type' => \elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
				'return_value' => 'yes',
				'label_on' => __( 'On', 'jvfrmtd' ),
				'label_off' => __( 'Off', 'jvfrmtd' ),
			)
		);
	}
}

if( ! function_exists( 'jvbpd_hide_show_widgets' ) ) {
	add_action('elementor/widgets/widgets_registered', 'jvbpd_hide_show_widgets');
	function jvbpd_hide_show_widgets( $widgets=Array() ){
		global $post;

		$filter_category = false;
		$filter_categories = Array(
			'map' => 'jvbpd-map-page',
			'single' => 'jvbpd-single-listing',
		);
		$is_template_type = get_post_meta( $post->ID, 'jvbpd_template_type', true );
		$wp_template = get_post_meta( $post->ID, '_wp_page_template', true );

		switch( $is_template_type ) {
			case 'single_listing_page' :
				$filter_category = $filter_categories[ 'single' ];
				break;
			case 'type_listing_archive' :
				$filter_category = $filter_categories[ 'map' ];
				break;
		}

		if( $wp_template == 'lava_lv_listing_map' ) {
			$filter_category = $filter_categories[ 'map' ];
		}

		foreach( $widgets->get_widget_types() as $widgetID => $widgetMeta ) {
			if( $widgetMeta->get_unique_name() == 'common' ) {
				continue;
			}
			if( $filter_category ) {
				if( $filter_category == $filter_categories[ 'map' ] && $widgetID == 'jvbpd-search-from-listing' ) {
					continue;
				}
				if( ! in_array( $filter_category, $widgetMeta->get_categories() ) ) {
					$widgets->unregister_widget_type( $widgetID );
				}
			}else{
				foreach( $filter_categories as $filter_category_key ) {
					if( in_array( $filter_category_key, $widgetMeta->get_categories() ) ) {
						$widgets->unregister_widget_type( $widgetID );
					}
				}
			}
		}

	}
}